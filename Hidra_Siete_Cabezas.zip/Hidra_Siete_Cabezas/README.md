# Hidra de las Siete Cabezas — mod para Minecraft Java 26.1.2 (Fabric)

Jefe legendario: una hidra voxel de **exactamente siete cabezas** que pierde cabezas durante el combate y las regenera
(con límites), con guarida en pantanos y bosques, recompensas, armas, armadura y Spawn Egg. Sin sonidos ni audio propios.

## Cómo compilar con GitHub Actions
1. Crea un repositorio y sube **el contenido** de esta carpeta (que `build.gradle` quede en la raíz).
2. Pestaña **Actions** → se ejecuta *Compilar mod* (o ejecútalo con *Run workflow*).
3. Descarga el artefacto `hidra-siete-cabezas` → `hidra-siete-cabezas-1.0.0.jar`.
4. Ponlo en `mods/` junto con **Fabric API** (Fabric Loader ≥ 0.19, Java 25).

> El `gradle-wrapper.jar` (binario) no viene incluido; el workflow lo genera solo (`gradle wrapper`). En local: `gradle wrapper --gradle-version 9.4.1` y luego `./gradlew build`.
> Versiones usadas (del fabric-example-mod 26.1.2): Loader 0.19.3, Loom 1.17-SNAPSHOT, Fabric API 0.155.2+26.1.2. Si Loom o Fabric API cambian, ajústalas en `gradle.properties`.

## Contenido
- **Entidad** `hidra:hydra_siete_cabezas` (modelo cúbico propio, textura PNG, animaciones propias por cabeza).
- **Spawn Egg** «Generador de Hidra de las Siete Cabezas» (solo inventario creativo, pestaña de huevos; sin receta ni loot ni spawn natural).
- **Guarida** (feature `hidra:hydra_lair`) en Pantano, Pantano de manglares, Bosque oscuro y Jungla: 1 de cada ~120 chunks de esos biomas. Claro de radio 11, ruinas, pilares, muros, huesos, cristales, vegetación propia y la Hidra dentro. Para cambiar la rareza edita `chance` en `data/hidra/worldgen/placed_feature/hydra_lair.json`.
- **Recompensas**: Escamas, Colmillos, Corazón, Núcleo Regenerativo, Esencia de Hidra, Espina Violeta, diamantes, esmeraldas, restos de netherita (60 %), manzana encantada (40 %), amatista.
- **Equipo**: espada, hacha, pico (Colmillos) y armadura de Escamas (el peto lleva un Corazón). Conjunto completo = regeneración pasiva (más fuerte con menos del 50 % de vida).
- **Núcleo Regenerativo** (uso único, clic derecho): cura, apaga fuego, quita veneno/wither/debilidad, Regeneración IV 30 s, Absorción III 60 s, Resistencia II 15 s.
- **Vegetación** `Hierba de la Hidra` y `Flor Violeta de la Hidra`: solo sueltan objeto con **Toque de Seda**; se rompen solos si el bloque de debajo desaparece o no es tierra válida.

## Combate
- Barra de jefe morada «Hidra de las Siete Cabezas». Vida base 1200 (configurable).
- **Cada cabeza tiene su vida** (90). Tu golpe va a la cabeza más cercana a tu línea de puntería (apunta hacia ella); el resto va al cuerpo. Una cabeza sin vida se destruye y deja un muñón.
- Cada cabeza elige objetivo y muerde por su cuenta; la IA general (un solo objetivo/pathfinding vanilla + un cerebro ligero por tick) coordina los ataques especiales: mordida múltiple, cola, pisotón con onda de choque, rugido (debilidad + lentitud) y ataque coordinado (rayos violeta + mordida de todas las cabezas).
- **Fases**: 1 (siete cabezas) → 2 (vida ≤ 66 % o ≥ 3 cabezas perdidas: más agresiva, regeneración más rápida, hasta 2 cabezas a la vez, mordidas venenosas) → 3 (vida ≤ 25 %: ataques combinados y regeneración con condición: 8 s sin recibir daño).
- **Regeneración**: tras `regen_seconds` (×1.5 fase 1, ×0.8 fase 2) la cabeza crece ~6 s con animación y partículas. Nunca supera 7 cabezas (son 7 contadores, no hay entidades nuevas → sin duplicados).
- **Límites**: `max_regenerations` por combate (9 por defecto); al agotarse los muñones quedan para siempre.
- **Si caen las 7 cabezas**: las heridas se **cauterizan**: no hay más regeneración, la vida queda ≤ 20 % y recibe +50 % de daño. Así se la derrota definitivamente.
- **Interrumpir/retrasar**: fuego (o la Hidra ardiendo) y las armas de Colmillo de Hidra cauterizan los muñones en crecimiento (20 s sin poder regenerar el muñón y se reinicia); los golpes fuertes hacen retroceder el crecimiento; cada golpe alarga la espera de las cabezas pendientes.

## Configuración (`config/hidra.properties`, se crea sola)
`boss_health`, `head_health`, `regen_seconds`, `max_regenerations`, `regen_head_health_percent`, `bite_damage`, `special_damage_percent`.

## Estructura
`src/main` (lógica, registro, mundo, datos) · `src/client` (modelo, render, animaciones) ·
`tools/` (scripts Python que regeneran modelo, texturas y JSON: `python3 tools/generar_modelo_y_texturas.py`, `python3 tools/generar_recursos.py`).

## Estado de verificación
Escrito contra la API de 26.1.2 (mapeos Mojang, Fabric API) usando la documentación oficial de Fabric. **No se compiló ni se probó en el juego** (el entorno donde se generó no tiene red ni los jars de Minecraft). Si Actions muestra errores de compilación, pásalos y se corrigen.
