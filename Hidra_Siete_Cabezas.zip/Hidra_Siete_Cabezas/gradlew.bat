@echo off
set APP_HOME=%~dp0
set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
if not exist "%CLASSPATH%" (
  echo Falta gradle\wrapper\gradle-wrapper.jar. Ejecuta: gradle wrapper --gradle-version 9.4.1
  exit /b 1
)
java -Dorg.gradle.appname=gradlew -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
