package com.hidra.entity;

import com.hidra.HidraConfig;
import com.hidra.registry.ModItems;
import java.util.EnumSet;
import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerBossEvent;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.util.Mth;
import net.minecraft.world.BossEvent;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageTypes;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * Hidra de las Siete Cabezas.
 *
 * Diseno ligero: UNA sola IA (objetivo + movimiento vanilla) y, encima, un "cerebro" por tick que
 * lleva siete contadores baratos (uno por cabeza). Las cabezas no son entidades: no hay duplicados
 * posibles. El estado visible (progreso de cada cabeza, mordidas, animacion) viaja por datos sincronizados.
 */
public class HydraEntity extends Monster {
    public static final int HEADS = 7;
    public static final int FULL = 255;
    public static final int ANIM_NONE = 0, ANIM_TAIL = 1, ANIM_STOMP = 2, ANIM_ROAR = 3, ANIM_COORD = 4;
    public static final int BITE_TICKS = 14;
    private static final int BITE_HIT_REMAINING = 7;
    private static final double BITE_RANGE = 13.0D;

    private static final EntityDataAccessor<Long> DATA_PROGRESS = SynchedEntityData.defineId(HydraEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> DATA_BITES = SynchedEntityData.defineId(HydraEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_ANIM = SynchedEntityData.defineId(HydraEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_PHASE = SynchedEntityData.defineId(HydraEntity.class, EntityDataSerializers.INT);

    // ---- estado de servidor (se guarda en NBT) ----
    private final int[] progress = new int[HEADS];   // 0 = destruida, 1..254 = creciendo, 255 = completa
    private final int[] headHp = new int[HEADS];
    private final int[] regenWait = new int[HEADS];
    private final int[] cauterTicks = new int[HEADS];
    private int totalRegens;
    private int phase = 1;
    private boolean cauterized;
    // ---- estado temporal ----
    private final int[] biteTimer = new int[HEADS];
    private final int[] biteCd = new int[HEADS];
    private final Player[] biteTarget = new Player[HEADS];
    private int biteMask;
    private int ticksSinceHurt = 1000;
    private int specialCd = 100;
    private int animId, animTicks, animDuration, chainPending, multiTicks;
    private List<Player> nearby = List.of();
    private final ServerBossEvent bossEvent = new ServerBossEvent(
            Component.translatable("entity.hidra.hydra_siete_cabezas"),
            BossEvent.BossBarColor.PURPLE, BossEvent.BossBarOverlay.PROGRESS);

    // ---- estado de cliente (animacion) ----
    public int clientAnimId, clientAnimStart, clientLastMask;
    public final int[] clientBiteStart = new int[HEADS];

    public HydraEntity(EntityType<? extends HydraEntity> type, Level level) {
        super(type, level);
        for (int i = 0; i < HEADS; i++) {
            progress[i] = FULL;
            headHp[i] = HidraConfig.headHealth;
        }
        this.bossEvent.setDarkenScreen(false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, HidraConfig.bossHealth)
                .add(Attributes.ARMOR, 10.0D)
                .add(Attributes.ATTACK_DAMAGE, 12.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.27D)
                .add(Attributes.KNOCKBACK_RESISTANCE, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 40.0D)
                .add(Attributes.STEP_HEIGHT, 1.6D);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(DATA_PROGRESS, packProgress(new int[]{FULL, FULL, FULL, FULL, FULL, FULL, FULL}));
        builder.define(DATA_BITES, 0);
        builder.define(DATA_ANIM, 0);
        builder.define(DATA_PHASE, 1);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(1, new ChaseGoal(this));
        this.goalSelector.addGoal(5, new RandomStrollGoal(this, 0.6D, 500));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 24.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
    }

    /** Movimiento: se acerca al objetivo hasta quedar a unos 7 bloques (las cabezas alcanzan lejos). */
    private static class ChaseGoal extends Goal {
        private final HydraEntity hydra;
        private int repath;

        ChaseGoal(HydraEntity hydra) {
            this.hydra = hydra;
            this.setFlags(EnumSet.of(Goal.Flag.MOVE));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = hydra.getTarget();
            return t != null && t.isAlive();
        }

        @Override
        public void tick() {
            LivingEntity t = hydra.getTarget();
            if (t == null) return;
            hydra.getLookControl().setLookAt(t, 20.0F, 20.0F);
            if (--repath <= 0) {
                repath = 10 + hydra.getRandom().nextInt(6);
                if (hydra.distanceToSqr(t) > 49.0D) hydra.getNavigation().moveTo(t, 1.0D);
                else hydra.getNavigation().stop();
            }
        }

        @Override
        public void stop() {
            hydra.getNavigation().stop();
        }
    }

    // =====================================================================================
    //  Utilidades de cabezas
    // =====================================================================================
    public static long packProgress(int[] p) {
        long v = 0;
        for (int i = 0; i < HEADS; i++) v |= ((long) (p[i] & 0xFF)) << (8 * i);
        return v;
    }

    /** 0..1 : crecimiento visible de la cabeza i (0 = muñon, 1 = completa). */
    public float headGrowth(int i) {
        return ((entityData.get(DATA_PROGRESS) >> (8 * i)) & 0xFFL) / 255.0F;
    }

    public int getBiteMask() { return entityData.get(DATA_BITES); }
    public int getPhase() { return entityData.get(DATA_PHASE); }

    public int aliveHeads() {
        int n = 0;
        for (int i = 0; i < HEADS; i++) if (progress[i] == FULL) n++;
        return n;
    }

    private int missingHeads() { return HEADS - aliveHeads(); }

    /** Posicion aproximada de la boca de la cabeza i (coherente con el modelo). */
    public Vec3 headPos(int i) {
        int c = i - 3;
        double rad = Math.toRadians(this.yBodyRot);
        double fwd = 4.3D + (3 - Math.abs(c)) * 0.25D;
        double left = c * 1.5D;
        double fx = -Math.sin(rad), fz = Math.cos(rad);
        double lx = Math.cos(rad), lz = Math.sin(rad);
        return new Vec3(getX() + fx * fwd + lx * left, getY() + 8.0D, getZ() + fz * fwd + lz * left);
    }

    private Vec3 stumpPos(int i) {
        int c = i - 3;
        double rad = Math.toRadians(this.yBodyRot);
        double fwd = 2.4D, left = c * 0.6D;
        return new Vec3(getX() - Math.sin(rad) * fwd + Math.cos(rad) * left, getY() + 5.3D,
                getZ() + Math.cos(rad) * fwd + Math.sin(rad) * left);
    }

    private double forwardDot(Entity e) {
        double rad = Math.toRadians(this.yBodyRot);
        double dx = e.getX() - getX(), dz = e.getZ() - getZ();
        double len = Math.sqrt(dx * dx + dz * dz) + 1.0E-6;
        return (-Math.sin(rad) * dx + Math.cos(rad) * dz) / len;
    }

    // =====================================================================================
    //  Dano: cada cabeza tiene su propia vida
    // =====================================================================================
    @Override
    public boolean hurtServer(ServerLevel level, DamageSource source, float amount) {
        if (source.is(DamageTypes.IN_WALL) || source.is(DamageTypes.CRAMMING)) return false;
        if (isDeadOrDying() || source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) {
            return super.hurtServer(level, source, amount);
        }
        int head = pickHead(source);
        float body = head >= 0 ? amount * 0.6F : amount;
        if (cauterized) body *= 1.5F;
        boolean ok = super.hurtServer(level, source, body);
        if (ok && !isDeadOrDying()) {
            ticksSinceHurt = 0;
            interruptRegeneration(level, source, amount);
            if (head >= 0) damageHead(level, head, Math.min(amount, HidraConfig.headHealth * 0.5F));
        }
        return ok;
    }

    /** La cabeza que recibe el golpe es la mas cercana a la linea de punteria del atacante. */
    private int pickHead(DamageSource source) {
        Entity attacker = source.getEntity();
        Entity direct = source.getDirectEntity();
        Vec3 origin, dir;
        if (attacker != null) {
            origin = attacker.getEyePosition();
            dir = attacker.getLookAngle();
        } else if (direct != null && direct.getDeltaMovement().lengthSqr() > 1.0E-4) {
            origin = direct.position();
            dir = direct.getDeltaMovement().normalize();
        } else {
            return -1;
        }
        int best = -1;
        double bestD = 4.0D;
        for (int i = 0; i < HEADS; i++) {
            if (progress[i] != FULL) continue;
            Vec3 hp = headPos(i);
            double t = Math.max(0.0D, hp.subtract(origin).dot(dir));
            double d = hp.distanceTo(origin.add(dir.scale(t)));
            if (d < bestD) { bestD = d; best = i; }
        }
        return best;
    }

    private void damageHead(ServerLevel level, int i, float amount) {
        headHp[i] -= Math.max(1, Math.round(amount));
        if (headHp[i] <= 0) destroyHead(level, i);
    }

    private void destroyHead(ServerLevel level, int i) {
        progress[i] = 0;
        headHp[i] = 0;
        biteTimer[i] = 0;
        biteMask &= ~(1 << i);
        regenWait[i] = baseRegenWait();
        Vec3 p = headPos(i);
        level.sendParticles(ParticleTypes.WITCH, p.x, p.y, p.z, 40, 0.8, 0.8, 0.8, 0.1);
        level.sendParticles(ParticleTypes.POOF, p.x, p.y, p.z, 12, 0.6, 0.6, 0.6, 0.05);
        level.sendParticles(ParticleTypes.PORTAL, p.x, p.y, p.z, 30, 0.8, 0.8, 0.8, 0.5);
        if (aliveHeads() == 0 && !anyGrowing()) {
            // Mecanica anti-regeneracion infinita: las heridas se cauterizan y el jefe queda a merced del jugador.
            cauterized = true;
            for (int k = 0; k < HEADS; k++) regenWait[k] = Integer.MAX_VALUE / 2;
            setHealth(Math.min(getHealth(), getMaxHealth() * 0.2F));
            announce("msg.hidra.cauterized");
        }
        pushSyncedState();
    }

    private boolean anyGrowing() {
        for (int i = 0; i < HEADS; i++) if (progress[i] > 0 && progress[i] < FULL) return true;
        return false;
    }

    private int baseRegenWait() {
        float f = phase == 1 ? 1.5F : phase == 2 ? 0.8F : 1.0F;
        return Math.round(HidraConfig.regenSeconds * 20 * f);
    }

    /** Interrumpir / retrasar la regeneracion: fuego o armas de Hidra cauterizan; los golpes fuertes retroceden el crecimiento. */
    private void interruptRegeneration(ServerLevel level, DamageSource source, float amount) {
        boolean cauterizing = source.is(DamageTypeTags.IS_FIRE) || this.isOnFire()
                || (source.getEntity() instanceof LivingEntity a && isHydraWeapon(a));
        boolean told = false;
        for (int i = 0; i < HEADS; i++) {
            if (progress[i] > 0 && progress[i] < FULL) {
                if (cauterizing) {
                    progress[i] = 0;
                    cauterTicks[i] = 1200;
                    regenWait[i] = baseRegenWait();
                    Vec3 s = stumpPos(i);
                    level.sendParticles(ParticleTypes.FLAME, s.x, s.y, s.z, 14, 0.4, 0.4, 0.4, 0.03);
                    if (!told) { announce("msg.hidra.cauter_head"); told = true; }
                } else if (amount >= 4.0F) {
                    progress[i] = Math.max(1, progress[i] - (amount >= 8.0F ? 50 : 12));
                }
            } else if (progress[i] == 0 && regenWait[i] < Integer.MAX_VALUE / 4) {
                if (cauterizing) cauterTicks[i] = Math.max(cauterTicks[i], 600);
                regenWait[i] = Math.min(regenWait[i] + 10, baseRegenWait() * 3);
            }
        }
    }

    private static boolean isHydraWeapon(LivingEntity a) {
        var s = a.getMainHandItem();
        return s.is(ModItems.HYDRA_SWORD) || s.is(ModItems.HYDRA_AXE) || s.is(ModItems.HYDRA_PICKAXE);
    }

    private void announce(String key) {
        for (Player p : nearby) p.displayClientMessage(Component.translatable(key), true);
        if (nearby.isEmpty() && level() instanceof ServerLevel sl) {
            for (ServerPlayer p : sl.players()) if (p.distanceToSqr(this) < 64 * 64) p.displayClientMessage(Component.translatable(key), true);
        }
    }

    // =====================================================================================
    //  Tick de servidor
    // =====================================================================================
    @Override
    public void tick() {
        super.tick();
        if (level() instanceof ServerLevel sl && isAlive()) serverTick(sl);
    }

    private void serverTick(ServerLevel level) {
        ticksSinceHurt++;
        if (multiTicks > 0) multiTicks--;
        if (tickCount % 10 == 0) {
            nearby = level.getEntitiesOfClass(Player.class, getBoundingBox().inflate(24.0D, 12.0D, 24.0D),
                    p -> p.isAlive() && !p.isCreative() && !p.isSpectator());
            updatePhase(level);
        }
        tickRegeneration(level);
        tickSpecial(level);
        tickBites(level);
        pushSyncedState();
        if (tickCount % 5 == 0) bossEvent.setProgress(Mth.clamp(getHealth() / getMaxHealth(), 0.0F, 1.0F));
    }

    private void pushSyncedState() {
        entityData.set(DATA_PROGRESS, packProgress(progress));
        entityData.set(DATA_BITES, biteMask);
        entityData.set(DATA_PHASE, phase);
    }

    private void updatePhase(ServerLevel level) {
        float pct = getHealth() / getMaxHealth();
        int p = pct <= 0.25F ? 3 : (pct <= 0.66F || missingHeads() >= 3 ? 2 : 1);
        if (p > phase) {
            phase = p;
            startAnim(ANIM_ROAR, 44);
            specialCd = 100;
            announce(p == 2 ? "msg.hidra.phase2" : "msg.hidra.phase3");
        }
    }

    // ---------------- regeneracion ----------------
    private void tickRegeneration(ServerLevel level) {
        if (cauterized) return;
        int growing = 0;
        for (int i = 0; i < HEADS; i++) if (progress[i] > 0 && progress[i] < FULL) growing++;
        int maxSimul = phase == 2 ? 2 : 1;
        boolean calm = phase != 3 || ticksSinceHurt >= 160; // fase 3: exige 8 s sin recibir dano
        for (int i = 0; i < HEADS; i++) {
            if (progress[i] == 0) {
                if (cauterTicks[i] > 0) { cauterTicks[i]--; continue; }
                if (totalRegens + growing >= HidraConfig.maxRegenerations) continue; // presupuesto agotado
                if (regenWait[i] > 0) { if (calm) regenWait[i]--; continue; }
                if (growing < maxSimul && calm) { progress[i] = 1; growing++; }
            } else if (progress[i] < FULL) {
                progress[i] = Math.min(FULL, progress[i] + 2);
                if (tickCount % 4 == 0) {
                    Vec3 s = stumpPos(i);
                    level.sendParticles(ParticleTypes.WITCH, s.x, s.y + 0.5D + progress[i] / 60.0D, s.z, 3, 0.4, 0.4, 0.4, 0.05);
                }
                if (progress[i] >= FULL) completeRegeneration(level, i);
            }
        }
    }

    private void completeRegeneration(ServerLevel level, int i) {
        progress[i] = FULL;
        headHp[i] = Math.max(10, HidraConfig.headHealth * HidraConfig.regenHealthPercent / 100);
        totalRegens++;
        Vec3 p = headPos(i);
        level.sendParticles(ParticleTypes.WITCH, p.x, p.y, p.z, 50, 1.0, 1.0, 1.0, 0.15);
        level.sendParticles(ParticleTypes.REVERSE_PORTAL, p.x, p.y, p.z, 30, 1.0, 1.0, 1.0, 0.2);
    }

    // ---------------- mordidas independientes ----------------
    private int biteCooldown() {
        int base = phase == 1 ? 38 : phase == 2 ? 28 : 18;
        return Math.max(10, base - missingHeads() * 2);
    }

    private void tickBites(ServerLevel level) {
        boolean mayStart = animId == ANIM_NONE || animId == ANIM_TAIL;
        for (int i = 0; i < HEADS; i++) {
            if (progress[i] != FULL) {
                if (biteTimer[i] > 0) { biteTimer[i] = 0; biteMask &= ~(1 << i); }
                continue;
            }
            if (biteTimer[i] > 0) {
                biteTimer[i]--;
                if (biteTimer[i] == BITE_HIT_REMAINING) strikeBite(level, i);
                if (biteTimer[i] == 0) biteMask &= ~(1 << i);
                continue;
            }
            if (biteCd[i] > 0) { biteCd[i]--; continue; }
            if (!mayStart || nearby.isEmpty()) continue;
            Player best = nearestTo(headPos(i), BITE_RANGE);
            if (best == null) { biteCd[i] = 8; continue; }
            biteTarget[i] = best;
            biteTimer[i] = BITE_TICKS;
            biteMask |= 1 << i;
            biteCd[i] = biteCooldown() + random.nextInt(25);
        }
    }

    private void startBite(int i, Player target) {
        if (progress[i] != FULL || biteTimer[i] > 0) return;
        biteTarget[i] = target;
        biteTimer[i] = BITE_TICKS;
        biteMask |= 1 << i;
    }

    private void strikeBite(ServerLevel level, int i) {
        Player t = biteTarget[i];
        if (t == null || !t.isAlive()) return;
        Vec3 hp = headPos(i);
        if (t.distanceToSqr(hp) > (BITE_RANGE + 2.0D) * (BITE_RANGE + 2.0D)) return;
        float dmg = HidraConfig.biteDamage * (1.0F + 0.15F * (phase - 1)) * (multiTicks > 0 ? 1.35F : 1.0F);
        t.hurtServer(level, damageSources().mobAttack(this), dmg);
        level.sendParticles(ParticleTypes.CRIT, t.getX(), t.getY() + 1.0D, t.getZ(), 8, 0.3, 0.4, 0.3, 0.2);
        if (phase >= 2 && random.nextFloat() < 0.35F) t.addEffect(new MobEffectInstance(MobEffects.POISON, 100, 0));
    }

    private Player nearestTo(Vec3 pos, double range) {
        Player best = null;
        double bd = range * range;
        for (Player p : nearby) {
            double d = p.distanceToSqr(pos);
            if (d < bd) { bd = d; best = p; }
        }
        return best;
    }

    // ---------------- ataques especiales ----------------
    private void startAnim(int id, int duration) {
        animId = id;
        animDuration = duration;
        animTicks = duration;
        entityData.set(DATA_ANIM, id);
    }

    private void tickSpecial(ServerLevel level) {
        if (animId != ANIM_NONE) {
            animTicks--;
            int t = animDuration - animTicks;
            switch (animId) {
                case ANIM_STOMP -> stompStep(level, t);
                case ANIM_TAIL -> tailStep(level, t);
                case ANIM_ROAR -> roarStep(level, t);
                case ANIM_COORD -> coordStep(level, t);
                default -> { }
            }
            if (animTicks <= 0) {
                int ended = animId;
                animId = ANIM_NONE;
                entityData.set(DATA_ANIM, 0);
                if (phase == 3 && ended != ANIM_COORD && random.nextFloat() < 0.35F && !nearby.isEmpty()) chainPending = 6;
            }
            return;
        }
        if (chainPending > 0) {
            if (--chainPending == 0) startAnim(ANIM_COORD, 56);
            return;
        }
        if (nearby.isEmpty()) return;
        if (specialCd > 0) { specialCd--; return; }
        chooseSpecial();
    }

    private void chooseSpecial() {
        Player n = nearestTo(position(), 40.0D);
        if (n == null) return;
        double d = Math.sqrt(distanceToSqr(n));
        boolean behind = forwardDot(n) < -0.25D;
        if (d < 12.0D && behind) startAnim(ANIM_TAIL, 26);
        else if (d < 9.0D && random.nextFloat() < 0.55F) startAnim(ANIM_STOMP, 34);
        else if (phase >= 2 && d < 26.0D && random.nextFloat() < 0.5F) startAnim(ANIM_COORD, 56);
        else if (random.nextFloat() < 0.35F) startAnim(ANIM_ROAR, 44);
        else multiBite();
        specialCd = (phase == 1 ? 140 : phase == 2 ? 100 : 60) + random.nextInt(50);
    }

    /** Mordida multiple: hasta 4 cabezas atacan escalonadas con bonus de dano. */
    private void multiBite() {
        multiTicks = 60;
        int started = 0;
        int offset = random.nextInt(HEADS);
        for (int k = 0; k < HEADS && started < 4; k++) {
            int i = (offset + k) % HEADS;
            if (progress[i] == FULL && biteTimer[i] == 0) {
                biteCd[i] = started * 5;
                started++;
            }
        }
    }

    private List<LivingEntity> victims(ServerLevel level, double radius) {
        return level.getEntitiesOfClass(LivingEntity.class, getBoundingBox().inflate(radius, 3.0D, radius),
                e -> e != this && !(e instanceof HydraEntity) && e.isAlive()
                        && !(e instanceof Player p && (p.isCreative() || p.isSpectator())));
    }

    private void ring(ServerLevel level, double r, int n, ParticleOptions type) {
        for (int k = 0; k < n; k++) {
            double a = Math.PI * 2 * k / n;
            level.sendParticles(type, getX() + Math.cos(a) * r, getY() + 0.2D, getZ() + Math.sin(a) * r, 1, 0.0, 0.1, 0.0, 0.02);
        }
    }

    private void stompStep(ServerLevel level, int t) {
        if (t == 16) {
            float dmg = 10.0F * HidraConfig.specialDamageMultiplier + 2.0F * phase;
            for (LivingEntity e : victims(level, 11.0D)) {
                double dx = e.getX() - getX(), dz = e.getZ() - getZ();
                if (dx * dx + dz * dz > 121.0D) continue;
                float f = e.getY() - getY() > 1.5D ? 0.4F : 1.0F; // saltar la onda reduce el dano
                e.hurtServer(level, damageSources().mobAttack(this), dmg * f);
                e.knockback(1.1D, -dx, -dz);
            }
            ring(level, 3.0D, 20, ParticleTypes.CLOUD);
            level.sendParticles(ParticleTypes.EXPLOSION, getX(), getY() + 0.3D, getZ(), 3, 1.5, 0.1, 1.5, 0.0);
        } else if (t == 18) ring(level, 6.0D, 28, ParticleTypes.CLOUD);
        else if (t == 20) ring(level, 9.0D, 36, ParticleTypes.WITCH);
        else if (t == 22) ring(level, 11.0D, 40, ParticleTypes.WITCH);
    }

    private void tailStep(ServerLevel level, int t) {
        if (t != 11) return;
        float dmg = 14.0F * HidraConfig.specialDamageMultiplier + 2.0F * phase;
        for (LivingEntity e : victims(level, 10.5D)) {
            if (forwardDot(e) > 0.35D || distanceToSqr(e) > 110.0D) continue;
            double dx = e.getX() - getX(), dz = e.getZ() - getZ();
            e.hurtServer(level, damageSources().mobAttack(this), dmg);
            e.knockback(1.7D, -dx, -dz);
            e.push(0.0D, 0.45D, 0.0D);
        }
        double rad = Math.toRadians(this.yBodyRot);
        for (int k = 0; k < 6; k++) {
            double r = 3.0D + k * 1.3D;
            level.sendParticles(ParticleTypes.SWEEP_ATTACK, getX() + Math.sin(rad) * r, getY() + 1.0D, getZ() - Math.cos(rad) * r, 1, 0, 0, 0, 0);
        }
    }

    private void roarStep(ServerLevel level, int t) {
        if (t == 14) {
            for (LivingEntity e : victims(level, 16.0D)) {
                e.addEffect(new MobEffectInstance(MobEffects.WEAKNESS, 200, 1));
                e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 100, 0));
                e.knockback(0.5D, getX() - e.getX(), getZ() - e.getZ());
            }
            ring(level, 4.0D, 24, ParticleTypes.CLOUD);
        } else if (t == 17) ring(level, 8.0D, 32, ParticleTypes.CLOUD);
        else if (t == 20) ring(level, 12.0D, 40, ParticleTypes.CLOUD);
    }

    private void coordStep(ServerLevel level, int t) {
        if (t == 16) {
            for (int i = 0; i < HEADS; i++) {
                if (progress[i] != FULL) continue;
                Vec3 from = headPos(i);
                Player tgt = nearestTo(from, 28.0D);
                if (tgt == null) continue;
                Vec3 to = tgt.getEyePosition();
                Vec3 dir = to.subtract(from);
                double len = dir.length();
                if (len < 0.5D) continue;
                Vec3 step = dir.scale(1.0D / len);
                for (double s = 0; s < len; s += 1.5D) {
                    level.sendParticles(ParticleTypes.WITCH, from.x + step.x * s, from.y + step.y * s, from.z + step.z * s, 2, 0.05, 0.05, 0.05, 0.0);
                }
                if (hasLineOfSight(tgt)) {
                    tgt.hurtServer(level, damageSources().mobAttack(this), 8.0F * HidraConfig.specialDamageMultiplier + phase);
                    tgt.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 60, 1));
                }
            }
        } else if (t == 36 && phase >= 2) {
            Player n = nearestTo(position(), 30.0D);
            for (int i = 0; i < HEADS; i++) if (n != null) startBite(i, n);
            multiTicks = 40;
        }
    }

    // =====================================================================================
    //  Muerte, jefe, persistencia
    // =====================================================================================
    @Override
    public void die(DamageSource source) {
        super.die(source);
        biteMask = 0;
        animId = ANIM_NONE;
        entityData.set(DATA_BITES, 0);
        entityData.set(DATA_ANIM, 0);
        bossEvent.setProgress(0.0F);
    }

    /** Muerte mas larga (4 s) para que se vea la animacion de derrumbe. */
    protected void tickDeath() {
        ++this.deathTime;
        if (this.deathTime >= 80 && !this.level().isClientSide() && !this.isRemoved()) {
            this.level().broadcastEntityEvent(this, (byte) 60);
            this.remove(Entity.RemovalReason.KILLED);
        }
    }

    protected int getBaseExperienceReward(ServerLevel level) {
        return 1500;
    }

    @Override
    public void startSeenByPlayer(ServerPlayer player) {
        super.startSeenByPlayer(player);
        bossEvent.addPlayer(player);
    }

    @Override
    public void stopSeenByPlayer(ServerPlayer player) {
        super.stopSeenByPlayer(player);
        bossEvent.removePlayer(player);
    }

    @Override
    public boolean removeWhenFarAway(double distance) { return false; }

    @Override
    public boolean isPushable() { return false; }

    /** Las cabezas sobresalen del cuerpo: ampliar el volumen de culling del render. */
    public AABB getBoundingBoxForCulling() {
        return getBoundingBox().inflate(5.0D, 6.0D, 5.0D);
    }

    @Override
    protected void addAdditionalSaveData(ValueOutput out) {
        super.addAdditionalSaveData(out);
        for (int i = 0; i < HEADS; i++) {
            out.putInt("prog" + i, progress[i]);
            out.putInt("hp" + i, headHp[i]);
            out.putInt("wait" + i, regenWait[i]);
            out.putInt("caut" + i, cauterTicks[i]);
        }
        out.putInt("total_regens", totalRegens);
        out.putInt("phase", phase);
        out.putInt("cauterized", cauterized ? 1 : 0);
    }

    @Override
    protected void readAdditionalSaveData(ValueInput in) {
        super.readAdditionalSaveData(in);
        for (int i = 0; i < HEADS; i++) {
            progress[i] = Mth.clamp(in.getInt("prog" + i).orElse(FULL), 0, FULL);
            headHp[i] = in.getInt("hp" + i).orElse(HidraConfig.headHealth);
            regenWait[i] = in.getInt("wait" + i).orElse(0);
            cauterTicks[i] = in.getInt("caut" + i).orElse(0);
        }
        totalRegens = in.getInt("total_regens").orElse(0);
        phase = Mth.clamp(in.getInt("phase").orElse(1), 1, 3);
        cauterized = in.getInt("cauterized").orElse(0) == 1;
        pushSyncedState();
    }

    // =====================================================================================
    //  Cliente: registrar el inicio de cada animacion
    // =====================================================================================
    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> accessor) {
        super.onSyncedDataUpdated(accessor);
        if (!level().isClientSide()) return;
        if (accessor == DATA_ANIM) {
            clientAnimId = entityData.get(DATA_ANIM);
            clientAnimStart = tickCount;
        } else if (accessor == DATA_BITES) {
            int mask = entityData.get(DATA_BITES);
            for (int i = 0; i < HEADS; i++) {
                if (((mask >> i) & 1) == 1 && ((clientLastMask >> i) & 1) == 0) clientBiteStart[i] = tickCount;
            }
            clientLastMask = mask;
        }
    }
}
