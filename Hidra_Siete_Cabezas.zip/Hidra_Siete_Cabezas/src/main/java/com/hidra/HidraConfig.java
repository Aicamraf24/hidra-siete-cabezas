package com.hidra;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;
import net.fabricmc.loader.api.FabricLoader;

/** Configuracion sencilla en config/hidra.properties (se crea sola la primera vez). */
public final class HidraConfig {
    public static int bossHealth = 1200;
    public static int headHealth = 90;
    public static int regenSeconds = 40;
    public static int maxRegenerations = 9;
    public static int regenHealthPercent = 70;
    public static float biteDamage = 9.0F;
    public static float specialDamageMultiplier = 1.0F;

    private HidraConfig() {}

    public static void load() {
        Path path = FabricLoader.getInstance().getConfigDir().resolve("hidra.properties");
        Properties p = new Properties();
        try {
            if (Files.exists(path)) {
                try (var in = Files.newInputStream(path)) { p.load(in); }
            }
        } catch (IOException e) {
            HidraMod.LOGGER.warn("No se pudo leer hidra.properties, se usan los valores por defecto.", e);
        }
        bossHealth = geti(p, "boss_health", bossHealth, 100, 100000);
        headHealth = geti(p, "head_health", headHealth, 5, 10000);
        regenSeconds = geti(p, "regen_seconds", regenSeconds, 3, 3600);
        maxRegenerations = geti(p, "max_regenerations", maxRegenerations, 0, 100);
        regenHealthPercent = geti(p, "regen_head_health_percent", regenHealthPercent, 10, 100);
        biteDamage = geti(p, "bite_damage", (int) biteDamage, 1, 200);
        specialDamageMultiplier = geti(p, "special_damage_percent", 100, 10, 1000) / 100.0F;
        try {
            Properties out = new Properties();
            out.setProperty("boss_health", String.valueOf(bossHealth));
            out.setProperty("head_health", String.valueOf(headHealth));
            out.setProperty("regen_seconds", String.valueOf(regenSeconds));
            out.setProperty("max_regenerations", String.valueOf(maxRegenerations));
            out.setProperty("regen_head_health_percent", String.valueOf(regenHealthPercent));
            out.setProperty("bite_damage", String.valueOf((int) biteDamage));
            out.setProperty("special_damage_percent", String.valueOf(Math.round(specialDamageMultiplier * 100)));
            try (OutputStream os = Files.newOutputStream(path)) {
                out.store(os, "Hidra de las Siete Cabezas - regen_seconds = tiempo base (s) para regenerar una cabeza; "
                        + "max_regenerations = regeneraciones totales por combate");
            }
        } catch (IOException ignored) {
        }
    }

    private static int geti(Properties p, String k, int def, int min, int max) {
        try {
            return Math.max(min, Math.min(max, Integer.parseInt(p.getProperty(k, String.valueOf(def)).trim())));
        } catch (NumberFormatException e) {
            return def;
        }
    }
}
