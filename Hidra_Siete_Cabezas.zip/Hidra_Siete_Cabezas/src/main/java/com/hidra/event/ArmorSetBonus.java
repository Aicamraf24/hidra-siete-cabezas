package com.hidra.event;

import com.hidra.registry.ModItems;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EquipmentSlot;

/** Conjunto completo de Escamas de Hidra: regeneracion pasiva (mas fuerte con poca vida). */
public final class ArmorSetBonus {
    private ArmorSetBonus() {}

    public static void init() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (server.getTickCount() % 40 != 0) return;
            for (ServerPlayer p : server.getPlayerList().getPlayers()) {
                if (p.getItemBySlot(EquipmentSlot.HEAD).is(ModItems.HYDRA_HELMET)
                        && p.getItemBySlot(EquipmentSlot.CHEST).is(ModItems.HYDRA_CHESTPLATE)
                        && p.getItemBySlot(EquipmentSlot.LEGS).is(ModItems.HYDRA_LEGGINGS)
                        && p.getItemBySlot(EquipmentSlot.FEET).is(ModItems.HYDRA_BOOTS)) {
                    int amp = p.getHealth() < p.getMaxHealth() * 0.5F ? 1 : 0;
                    p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 100, amp, true, false, true));
                }
            }
        });
    }
}
