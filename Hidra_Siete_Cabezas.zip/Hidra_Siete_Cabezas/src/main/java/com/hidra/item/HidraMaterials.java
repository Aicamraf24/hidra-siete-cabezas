package com.hidra.item;

import com.hidra.HidraMod;
import java.util.Map;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ToolMaterial;
import net.minecraft.world.item.equipment.ArmorMaterial;
import net.minecraft.world.item.equipment.ArmorType;
import net.minecraft.world.item.equipment.EquipmentAsset;
import net.minecraft.world.item.equipment.EquipmentAssets;

public final class HidraMaterials {
    public static final TagKey<Item> REPAIRS_HYDRA_GEAR =
            TagKey.create(Registries.ITEM, HidraMod.id("repairs_hydra_gear"));

    public static final ToolMaterial HYDRA_TOOL = new ToolMaterial(
            BlockTags.INCORRECT_FOR_NETHERITE_TOOL, 2400, 9.0F, 5.0F, 18, REPAIRS_HYDRA_GEAR);

    public static final int ARMOR_BASE_DURABILITY = 40;
    public static final ResourceKey<EquipmentAsset> HYDRA_ASSET =
            ResourceKey.create(EquipmentAssets.ROOT_ID, HidraMod.id("hydra"));

    public static final ArmorMaterial HYDRA_ARMOR = new ArmorMaterial(
            ARMOR_BASE_DURABILITY,
            Map.of(ArmorType.HELMET, 3, ArmorType.CHESTPLATE, 8, ArmorType.LEGGINGS, 6, ArmorType.BOOTS, 3),
            17, SoundEvents.ARMOR_EQUIP_NETHERITE, 3.0F, 0.1F, REPAIRS_HYDRA_GEAR, HYDRA_ASSET);

    private HidraMaterials() {}
}
