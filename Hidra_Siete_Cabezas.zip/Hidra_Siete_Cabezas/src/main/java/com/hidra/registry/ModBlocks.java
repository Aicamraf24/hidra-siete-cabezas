package com.hidra.registry;

import com.hidra.HidraMod;
import com.hidra.block.HidraPlantBlock;
import java.util.function.Function;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.PushReaction;

public final class ModBlocks {
    public static final Block HIDRA_GRASS = register("hidra_grass",
            p -> new HidraPlantBlock(p, 13.0D),
            BlockBehaviour.Properties.of().noCollision().randomTicks().instabreak().sound(SoundType.GRASS).pushReaction(PushReaction.DESTROY));
    public static final Block HIDRA_FLOWER = register("hidra_flower",
            p -> new HidraPlantBlock(p, 11.0D),
            BlockBehaviour.Properties.of().noCollision().randomTicks().instabreak().sound(SoundType.GRASS)
                    .lightLevel(s -> 7).pushReaction(PushReaction.DESTROY));

    private ModBlocks() {}

    private static Block register(String name, Function<BlockBehaviour.Properties, Block> factory, BlockBehaviour.Properties props) {
        ResourceKey<Block> key = ResourceKey.create(Registries.BLOCK, HidraMod.id(name));
        Block block = Registry.register(BuiltInRegistries.BLOCK, key, factory.apply(props.setId(key)));
        ResourceKey<Item> itemKey = ResourceKey.create(Registries.ITEM, HidraMod.id(name));
        Registry.register(BuiltInRegistries.ITEM, itemKey,
                new BlockItem(block, new Item.Properties().setId(itemKey).useBlockDescriptionPrefix()));
        return block;
    }

    public static void init() {}
}
