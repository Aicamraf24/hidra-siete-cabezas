package com.hidra.registry;

import com.hidra.HidraMod;
import com.hidra.world.HydraLairFeature;
import net.fabricmc.fabric.api.biome.v1.BiomeModifications;
import net.fabricmc.fabric.api.biome.v1.BiomeSelectors;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.biome.Biomes;
import net.minecraft.world.level.levelgen.GenerationStep;
import net.minecraft.world.level.levelgen.placement.PlacedFeature;

public final class ModFeatures {
    public static final HydraLairFeature HYDRA_LAIR = Registry.register(BuiltInRegistries.FEATURE,
            HidraMod.id("hydra_lair"), new HydraLairFeature());

    private ModFeatures() {}

    public static void init() {
        ResourceKey<PlacedFeature> placed = ResourceKey.create(Registries.PLACED_FEATURE, HidraMod.id("hydra_lair"));
        BiomeModifications.addFeature(
                BiomeSelectors.includeByKey(Biomes.SWAMP, Biomes.MANGROVE_SWAMP, Biomes.DARK_FOREST, Biomes.JUNGLE),
                GenerationStep.Decoration.SURFACE_STRUCTURES, placed);
    }
}
