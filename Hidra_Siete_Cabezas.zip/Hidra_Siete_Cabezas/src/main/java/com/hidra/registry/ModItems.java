package com.hidra.registry;

import com.hidra.HidraMod;
import com.hidra.item.HidraMaterials;
import com.hidra.item.RegenerativeCoreItem;
import java.util.function.Function;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.SpawnEggItem;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.equipment.ArmorType;

public final class ModItems {
    public static final Item HYDRA_SCALE = reg("hydra_scale", Item::new, new Item.Properties());
    public static final Item HYDRA_FANG = reg("hydra_fang", Item::new, new Item.Properties());
    public static final Item HYDRA_HEART = reg("hydra_heart", Item::new, new Item.Properties().rarity(Rarity.EPIC));
    public static final Item REGENERATIVE_CORE = reg("regenerative_core", RegenerativeCoreItem::new,
            new Item.Properties().rarity(Rarity.EPIC).stacksTo(4));
    public static final Item HYDRA_ESSENCE = reg("hydra_essence", Item::new, new Item.Properties().rarity(Rarity.RARE));
    public static final Item VIOLET_SPINE = reg("violet_spine", Item::new, new Item.Properties().rarity(Rarity.RARE));

    public static final Item HYDRA_SWORD = reg("hydra_sword", Item::new,
            new Item.Properties().sword(HidraMaterials.HYDRA_TOOL, 3.0F, -2.4F).rarity(Rarity.EPIC));
    public static final Item HYDRA_AXE = reg("hydra_axe",
            p -> new AxeItem(HidraMaterials.HYDRA_TOOL, 5.0F, -3.0F, p), new Item.Properties().rarity(Rarity.EPIC));
    public static final Item HYDRA_PICKAXE = reg("hydra_pickaxe", Item::new,
            new Item.Properties().pickaxe(HidraMaterials.HYDRA_TOOL, 1.0F, -2.8F).rarity(Rarity.EPIC));

    public static final Item HYDRA_HELMET = reg("hydra_helmet", Item::new, armor(ArmorType.HELMET));
    public static final Item HYDRA_CHESTPLATE = reg("hydra_chestplate", Item::new, armor(ArmorType.CHESTPLATE));
    public static final Item HYDRA_LEGGINGS = reg("hydra_leggings", Item::new, armor(ArmorType.LEGGINGS));
    public static final Item HYDRA_BOOTS = reg("hydra_boots", Item::new, armor(ArmorType.BOOTS));

    /** Solo disponible en el inventario creativo; sin receta ni loot. */
    public static final Item HYDRA_SPAWN_EGG = reg("hydra_spawn_egg", SpawnEggItem::new,
            new Item.Properties().spawnEgg(ModEntities.HYDRA).rarity(Rarity.EPIC));

    private ModItems() {}

    private static Item.Properties armor(ArmorType type) {
        return new Item.Properties().humanoidArmor(HidraMaterials.HYDRA_ARMOR, type)
                .durability(type.getDurability(HidraMaterials.ARMOR_BASE_DURABILITY)).rarity(Rarity.EPIC);
    }

    private static Item reg(String name, Function<Item.Properties, Item> factory, Item.Properties props) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, HidraMod.id(name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(props.setId(key)));
    }

    public static void init() {
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.INGREDIENTS).register(out -> {
            out.accept(HYDRA_SCALE); out.accept(HYDRA_FANG); out.accept(HYDRA_HEART);
            out.accept(REGENERATIVE_CORE); out.accept(HYDRA_ESSENCE); out.accept(VIOLET_SPINE);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(out -> {
            out.accept(HYDRA_SWORD); out.accept(HYDRA_AXE);
            out.accept(HYDRA_HELMET); out.accept(HYDRA_CHESTPLATE); out.accept(HYDRA_LEGGINGS); out.accept(HYDRA_BOOTS);
        });
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.TOOLS_AND_UTILITIES).register(out -> out.accept(HYDRA_PICKAXE));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.SPAWN_EGGS).register(out -> out.accept(HYDRA_SPAWN_EGG));
        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.NATURAL_BLOCKS).register(out -> {
            out.accept(ModBlocks.HIDRA_GRASS); out.accept(ModBlocks.HIDRA_FLOWER);
        });
    }
}
