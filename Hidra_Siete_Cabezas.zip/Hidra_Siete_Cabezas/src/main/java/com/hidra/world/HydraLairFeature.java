package com.hidra.world;

import com.hidra.block.HidraPlantBlock;
import com.hidra.entity.HydraEntity;
import com.hidra.registry.ModBlocks;
import com.hidra.registry.ModEntities;
import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.WorldGenLevel;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SkullBlock;
import net.minecraft.world.level.block.VineBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;

/**
 * Guarida de la Hidra: claro circular (radio 11) con suelo de ruinas y barro, cuatro pilares
 * en ruinas, muros rotos, huesos y craneos, cristales morados, vegetacion propia y la Hidra dentro.
 * Todo queda a +-12 bloques del centro del chunk, dentro del area de escritura permitida.
 */
public class HydraLairFeature extends Feature<NoneFeatureConfiguration> {
    private static final int R = 11;

    public HydraLairFeature() {
        super(NoneFeatureConfiguration.CODEC);
    }

    @Override
    public boolean place(FeaturePlaceContext<NoneFeatureConfiguration> ctx) {
        WorldGenLevel level = ctx.level();
        RandomSource rnd = ctx.random();
        int cx = (ctx.origin().getX() & ~15) + 8;
        int cz = (ctx.origin().getZ() & ~15) + 8;
        int y0 = level.getHeight(Heightmap.Types.OCEAN_FLOOR_WG, cx, cz); // primer hueco libre sobre el suelo
        int surface = level.getHeight(Heightmap.Types.WORLD_SURFACE_WG, cx, cz);
        if (surface - y0 > 2 || y0 < 40) return false; // demasiada agua / cueva

        // 1) terreno: aplanar, rellenar y despejar
        for (int dx = -R; dx <= R; dx++) {
            for (int dz = -R; dz <= R; dz++) {
                double d2 = dx * dx + dz * dz;
                if (d2 > R * R + rnd.nextInt(10)) continue;
                int x = cx + dx, z = cz + dz;
                for (int y = y0 - 6; y < y0; y++) {
                    BlockPos p = new BlockPos(x, y, z);
                    BlockState s = level.getBlockState(p);
                    if (s.isAir() || !s.getFluidState().isEmpty() || s.is(Blocks.SHORT_GRASS)) set(level, p, Blocks.DIRT.defaultBlockState());
                }
                for (int y = y0; y <= y0 + 14; y++) set(level, new BlockPos(x, y, z), Blocks.AIR.defaultBlockState());
                set(level, new BlockPos(x, y0 - 1, z), floor(rnd, d2));
            }
        }
        // 2) altar central de cristal morado
        for (int dx = -2; dx <= 2; dx++) for (int dz = -2; dz <= 2; dz++) {
            if (Math.abs(dx) + Math.abs(dz) <= 3) {
                set(level, new BlockPos(cx + dx, y0 - 1, cz + dz),
                        (Math.abs(dx) + Math.abs(dz)) % 2 == 0 ? Blocks.CRYING_OBSIDIAN.defaultBlockState() : Blocks.POLISHED_DEEPSLATE.defaultBlockState());
            }
        }
        for (int k = 0; k < 6; k++) {
            double a = Math.PI * 2 * k / 6 + 0.3;
            BlockPos p = new BlockPos(cx + (int) Math.round(Math.cos(a) * 4), y0, cz + (int) Math.round(Math.sin(a) * 4));
            set(level, p, Blocks.AMETHYST_CLUSTER.defaultBlockState());
        }
        // 3) cuatro pilares en ruinas
        for (int k = 0; k < 4; k++) {
            double a = Math.PI / 4 + k * Math.PI / 2;
            pillar(level, rnd, cx + (int) Math.round(Math.cos(a) * 8), cz + (int) Math.round(Math.sin(a) * 8), y0, 3 + rnd.nextInt(5));
        }
        // 4) muros rotos (arcos de ruinas)
        for (int k = 0; k < 2; k++) {
            int sign = k == 0 ? 1 : -1;
            for (int i = -4; i <= 4; i++) {
                int x = cx + i, z = cz + sign * 10;
                int h = 1 + rnd.nextInt(4);
                if (Math.abs(i) <= 1 && rnd.nextInt(3) > 0) continue; // hueco de entrada
                for (int y = 0; y < h; y++) set(level, new BlockPos(x, y0 + y, z), brick(rnd));
            }
        }
        // 5) restos de criaturas: huesos y craneos
        for (int k = 0; k < 14; k++) {
            int x = cx + rnd.nextInt(2 * R - 4) - (R - 2), z = cz + rnd.nextInt(2 * R - 4) - (R - 2);
            if ((x - cx) * (x - cx) + (z - cz) * (z - cz) < 16) continue;
            BlockPos p = new BlockPos(x, y0, z);
            if (rnd.nextInt(3) == 0) {
                set(level, p, Blocks.SKELETON_SKULL.defaultBlockState().setValue(SkullBlock.ROTATION, rnd.nextInt(16)));
            } else {
                int len = 1 + rnd.nextInt(3);
                for (int i = 0; i < len; i++) set(level, p.offset(i, 0, 0), Blocks.BONE_BLOCK.defaultBlockState());
            }
        }
        // 6) vegetacion y telarañas
        for (int dx = -R; dx <= R; dx++) for (int dz = -R; dz <= R; dz++) {
            if (dx * dx + dz * dz > R * R) continue;
            BlockPos p = new BlockPos(cx + dx, y0, cz + dz);
            if (!level.getBlockState(p).isAir()) continue;
            int r = rnd.nextInt(100);
            Block plant = r < 14 ? ModBlocks.HIDRA_GRASS : r < 19 ? ModBlocks.HIDRA_FLOWER : null;
            if (plant != null && HidraPlantBlock.validSupport(level.getBlockState(p.below()))) {
                set(level, p, plant.defaultBlockState());
            } else if (r > 97) {
                set(level, p, Blocks.COBWEB.defaultBlockState());
            }
        }
        // 7) la Hidra
        HydraEntity hydra = new HydraEntity(ModEntities.HYDRA, level.getLevel());
        hydra.setPos(cx + 0.5D, y0, cz + 0.5D);
        hydra.setYRot(rnd.nextInt(360));
        hydra.setPersistenceRequired();
        level.addFreshEntity(hydra);
        return true;
    }

    private static void set(WorldGenLevel level, BlockPos p, BlockState s) {
        level.setBlock(p, s, 2);
    }

    private static BlockState brick(RandomSource r) {
        int v = r.nextInt(10);
        return (v < 5 ? Blocks.MOSSY_STONE_BRICKS : v < 8 ? Blocks.STONE_BRICKS : Blocks.CRACKED_STONE_BRICKS).defaultBlockState();
    }

    private static BlockState floor(RandomSource r, double d2) {
        int v = r.nextInt(100);
        if (d2 > 70) return (v < 40 ? Blocks.MOSS_BLOCK : v < 70 ? Blocks.MUD : v < 85 ? Blocks.PODZOL : Blocks.MOSSY_COBBLESTONE).defaultBlockState();
        return (v < 35 ? Blocks.MOSSY_STONE_BRICKS : v < 55 ? Blocks.CRACKED_STONE_BRICKS : v < 75 ? Blocks.MUD : v < 90 ? Blocks.MOSS_BLOCK : Blocks.COARSE_DIRT).defaultBlockState();
    }

    private static void pillar(WorldGenLevel level, RandomSource rnd, int x, int z, int y0, int h) {
        for (int y = 0; y < h; y++) {
            BlockPos p = new BlockPos(x, y0 + y, z);
            set(level, p, brick(rnd));
            for (Direction d : Direction.Plane.HORIZONTAL) {
                if (rnd.nextInt(3) == 0) {
                    BlockPos q = p.relative(d);
                    if (level.getBlockState(q).isAir()) {
                        set(level, q, Blocks.VINE.defaultBlockState().setValue(VineBlock.getPropertyForFace(d.getOpposite()), true));
                    }
                }
            }
        }
        if (rnd.nextBoolean()) set(level, new BlockPos(x, y0 + h, z), Blocks.AMETHYST_CLUSTER.defaultBlockState());
    }
}
