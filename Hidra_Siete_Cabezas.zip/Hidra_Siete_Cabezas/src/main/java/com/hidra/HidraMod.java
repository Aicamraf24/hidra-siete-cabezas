package com.hidra;

import com.hidra.event.ArmorSetBonus;
import com.hidra.registry.ModBlocks;
import com.hidra.registry.ModEntities;
import com.hidra.registry.ModFeatures;
import com.hidra.registry.ModItems;
import net.fabricmc.api.ModInitializer;
import net.minecraft.resources.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HidraMod implements ModInitializer {
    public static final String MOD_ID = "hidra";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        HidraConfig.load();
        ModEntities.init();
        ModBlocks.init();
        ModItems.init();
        ModFeatures.init();
        ArmorSetBonus.init();
        LOGGER.info("Hidra de las Siete Cabezas cargada.");
    }
}
