package com.hidra.client;

import com.hidra.client.model.HydraModelLayers;
import com.hidra.client.render.HydraRenderer;
import com.hidra.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.minecraft.client.renderer.entity.EntityRenderers;

public class HidraClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        HydraModelLayers.register();
        EntityRenderers.register(ModEntities.HYDRA, HydraRenderer::new);
    }
}
