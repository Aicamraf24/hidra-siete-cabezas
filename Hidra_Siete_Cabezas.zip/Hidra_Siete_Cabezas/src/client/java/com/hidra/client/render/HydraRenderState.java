package com.hidra.client.render;

import net.minecraft.client.renderer.entity.state.LivingEntityRenderState;

public class HydraRenderState extends LivingEntityRenderState {
    public final float[] growth = new float[7];
    public final float[] biteTime = new float[7]; // ticks desde que empezo la mordida; -1 = no muerde
    public int animId;
    public float animTime = -1.0F;
    public int phase = 1;
}
