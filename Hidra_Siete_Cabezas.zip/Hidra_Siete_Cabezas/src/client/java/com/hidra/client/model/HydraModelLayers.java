package com.hidra.client.model;

import com.hidra.HidraMod;
import net.fabricmc.fabric.api.client.rendering.v1.ModelLayerRegistry;
import net.minecraft.client.model.geom.ModelLayerLocation;

public final class HydraModelLayers {
    public static final ModelLayerLocation HYDRA = new ModelLayerLocation(HidraMod.id("hydra_siete_cabezas"), "main");

    private HydraModelLayers() {}

    public static void register() {
        ModelLayerRegistry.registerModelLayer(HYDRA, HydraLayer::create);
    }
}
