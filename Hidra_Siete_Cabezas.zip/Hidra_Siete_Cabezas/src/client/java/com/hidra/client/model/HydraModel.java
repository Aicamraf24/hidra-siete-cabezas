package com.hidra.client.model;

import com.hidra.client.render.HydraRenderState;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.util.Mth;

/**
 * Animacion de la hidra. Cada una de las 7 cabezas tiene fase propia de oscilacion, su propia
 * mordida (lunge + mandibula), su propio crecimiento (regeneracion) y su munon.
 */
public class HydraModel extends EntityModel<HydraRenderState> {
    private static final int N = 7;
    private static final float BITE_LEN = 14.0F;

    private final ModelPart body;
    private final ModelPart[] legs = new ModelPart[4];   // FL, FR, BL, BR
    private final ModelPart[] feet = new ModelPart[4];
    private final ModelPart[] tail = new ModelPart[5];
    private final ModelPart[] na = new ModelPart[N], nb = new ModelPart[N], nc = new ModelPart[N];
    private final ModelPart[] head = new ModelPart[N], jaw = new ModelPart[N], stump = new ModelPart[N];

    public HydraModel(ModelPart root) {
        super(root);
        body = root.getChild("body");
        String[] ln = {"FL", "FR", "BL", "BR"};
        for (int i = 0; i < 4; i++) {
            legs[i] = root.getChild("leg" + ln[i]);
            feet[i] = legs[i].getChild("foot" + ln[i]);
        }
        ModelPart t = root;
        for (int i = 0; i < 5; i++) {
            t = t.getChild("tail" + (i + 1));
            tail[i] = t;
        }
        for (int i = 0; i < N; i++) {
            na[i] = root.getChild("n" + i + "a");
            nb[i] = na[i].getChild("n" + i + "b");
            nc[i] = nb[i].getChild("n" + i + "c");
            head[i] = nc[i].getChild("h" + i);
            jaw[i] = head[i].getChild("j" + i);
            stump[i] = root.getChild("s" + i);
        }
    }

    private static float smooth(float x) {
        x = Mth.clamp(x, 0.0F, 1.0F);
        return x * x * (3.0F - 2.0F * x);
    }

    /** Curva de mordida: 0 en reposo, negativo al armar el golpe, 1 en el golpe. */
    private static float biteCurve(float p) {
        if (p < 0.3F) return -0.5F * smooth(p / 0.3F);
        if (p < 0.5F) return Mth.lerp(smooth((p - 0.3F) / 0.2F), -0.5F, 1.0F);
        return Mth.lerp(smooth((p - 0.5F) / 0.5F), 1.0F, 0.0F);
    }

    private static float jawCurve(float p) {
        if (p < 0.15F) return 0.0F;
        if (p < 0.45F) return smooth((p - 0.15F) / 0.3F);
        return 1.0F - smooth((p - 0.45F) / 0.2F);
    }

    @Override
    public void setupAnim(HydraRenderState s) {
        super.setupAnim(s);
        float t = s.ageInTicks;
        float speed = Mth.clamp(s.walkAnimationSpeed, 0.0F, 1.5F);
        float pos = s.walkAnimationPos;
        float gait = 0.45F + 0.5F * Mth.clamp((speed - 0.3F) / 0.6F, 0.0F, 1.0F); // caminar -> correr
        float run = Mth.clamp((speed - 0.5F) / 0.5F, 0.0F, 1.0F);
        float death = s.deathTime > 0.0F ? Mth.clamp(s.deathTime / 30.0F, 0.0F, 1.0F) : 0.0F;

        // ---- animacion especial global ----
        float at = s.animTime;
        float stompLift = 0, stompSlam = 0, tailSwing = 0, roar = 0, coord = 0;
        if (s.animId == 2 && at >= 0) {            // pisoton
            stompLift = at < 14 ? smooth(at / 14.0F) : 0.0F;
            stompSlam = at >= 14 ? Mth.clamp(1.0F - (at - 14.0F) / 8.0F, 0.0F, 1.0F) : 0.0F;
        } else if (s.animId == 1 && at >= 0) {      // cola
            tailSwing = Mth.lerp(smooth(at / 22.0F), 1.3F, -1.3F);
        } else if (s.animId == 3 && at >= 0) {      // rugido
            roar = at < 8 ? smooth(at / 8.0F) : Mth.clamp(1.0F - (at - 30.0F) / 14.0F, 0.0F, 1.0F);
        } else if (s.animId == 4 && at >= 0) {      // ataque coordinado
            coord = at / 56.0F;
        }

        // ---- cuerpo y patas ----
        float bob = Mth.abs(Mth.sin(pos * 0.4F)) * 2.5F * speed;
        float bodyDy = -bob + stompLift * -6.0F + stompSlam * 3.0F + death * 30.0F + roar * 1.5F * Mth.sin(t * 1.6F);
        body.y += bodyDy;
        body.xRot += stompLift * -0.10F + stompSlam * 0.06F + death * 0.15F;
        body.yRot += tailSwing * 0.05F;
        float amp = gait * speed * 1.1F;
        for (int i = 0; i < 4; i++) {
            float phase = (i == 0 || i == 3) ? 0.0F : Mth.PI;
            float sw = Mth.cos(pos * 0.4F + phase) * amp;
            legs[i].xRot += sw;
            feet[i].xRot += Math.max(0.0F, -sw) * 0.6F;
            legs[i].y += death * 12.0F;
        }
        legs[0].xRot += stompLift * -0.9F;
        legs[1].xRot += stompLift * -0.9F;
        legs[0].xRot += stompSlam * 0.3F;
        legs[1].xRot += stompSlam * 0.3F;
        for (int i = 0; i < 4; i++) { legs[i].zRot += (i % 2 == 0 ? 1 : -1) * death * 0.5F; }

        // ---- cola ----
        for (int i = 0; i < 5; i++) {
            float wave = Mth.sin(t * 0.09F - i * 0.7F) * 0.12F + Mth.sin(pos * 0.4F - i * 0.5F) * 0.14F * speed;
            tail[i].yRot += wave + (i < 3 ? tailSwing * 0.45F : tailSwing * 0.2F);
            tail[i].xRot += death * 0.06F;
        }
        tail[0].y += bodyDy;

        // ---- siete cabezas ----
        for (int i = 0; i < N; i++) {
            int c = i - 3;
            float g = s.growth[i];
            float idle = Mth.sin(t * 0.07F + i * 1.7F);
            float idle2 = Mth.cos(t * 0.05F + i * 2.3F);
            na[i].y += bodyDy;
            stump[i].y += bodyDy;

            // muñon / regeneracion
            boolean full = g >= 0.999F;
            stump[i].visible = !full;
            na[i].visible = g > 0.01F;
            if (!full && g > 0.01F) {
                float wr = (1.0F - g);
                na[i].xScale = na[i].zScale = 0.35F + 0.65F * g;
                na[i].yScale = g;
                na[i].zRot += Mth.sin(t * 0.9F + i) * 0.15F * wr;
                na[i].xRot += Mth.cos(t * 0.8F + i * 2.0F) * 0.12F * wr;
            }

            // oscilacion propia, independiente por cabeza
            na[i].xRot += idle * 0.06F + run * 0.18F;
            na[i].zRot += idle2 * 0.05F;
            nb[i].yRot += idle * 0.12F;
            nb[i].xRot += idle2 * 0.05F;
            nc[i].yRot += idle2 * 0.14F;
            head[i].xRot += idle * 0.06F;
            head[i].yRot += Mth.clamp(s.yRot * Mth.DEG_TO_RAD, -0.6F, 0.6F) * 0.4F + idle2 * 0.1F;
            jaw[i].xRot += 0.08F + (idle + 1.0F) * 0.04F;

            // mordida propia de esta cabeza
            float bt = s.biteTime[i];
            if (bt >= 0.0F && full) {
                float p = Mth.clamp(bt / BITE_LEN, 0.0F, 1.0F);
                float lunge = biteCurve(p);
                na[i].xRot += lunge * 0.55F;
                nb[i].xRot += lunge * 0.65F;
                nc[i].xRot += lunge * 0.65F;
                head[i].xRot -= lunge * 0.30F;
                nb[i].yRot += Mth.sin(p * Mth.PI) * c * -0.05F;
                jaw[i].xRot += jawCurve(p) * 0.95F;
            }
            // ataque coordinado: todas las cabezas se echan atras y golpean a la vez
            if (coord > 0.0F && full) {
                float lunge = coord < 0.28F ? -0.8F * smooth(coord / 0.28F)
                        : coord < 0.42F ? Mth.lerp(smooth((coord - 0.28F) / 0.14F), -0.8F, 1.0F)
                        : coord < 0.75F ? 1.0F - 0.4F * smooth((coord - 0.42F) / 0.33F) : Mth.lerp(smooth((coord - 0.75F) / 0.25F), 0.6F, 0.0F);
                na[i].xRot += lunge * 0.5F;
                nb[i].xRot += lunge * 0.55F;
                nc[i].xRot += lunge * 0.55F;
                jaw[i].xRot += Math.max(0.0F, lunge) * 0.9F + (coord < 0.28F ? smooth(coord / 0.28F) * 0.5F : 0.0F);
                na[i].zRot += Mth.sin(t * 2.0F + i) * 0.05F;
            }
            // rugido: cuellos hacia atras y mandibulas abiertas
            if (roar > 0.0F && full) {
                na[i].xRot += roar * -0.55F;
                nb[i].xRot += roar * -0.35F;
                head[i].xRot += roar * -0.25F;
                jaw[i].xRot += roar * 1.05F;
                nb[i].yRot += Mth.sin(t * 1.4F + i * 1.3F) * 0.08F * roar;
            }
            // pisoton: las cabezas se encogen un poco
            na[i].xRot += stompSlam * 0.25F;
            // muerte: cuellos y cabezas caen
            if (death > 0.0F) {
                na[i].xRot += death * 0.9F;
                nb[i].xRot += death * 0.6F;
                nc[i].xRot += death * 0.5F;
                head[i].xRot += death * 0.3F;
                jaw[i].xRot += death * 0.5F;
            }
        }
    }
}
