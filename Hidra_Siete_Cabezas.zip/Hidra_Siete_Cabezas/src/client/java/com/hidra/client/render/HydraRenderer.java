package com.hidra.client.render;

import com.hidra.HidraMod;
import com.hidra.client.model.HydraModel;
import com.hidra.client.model.HydraModelLayers;
import com.hidra.entity.HydraEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.Identifier;

public class HydraRenderer extends MobRenderer<HydraEntity, HydraRenderState, HydraModel> {
    private static final Identifier TEXTURE = HidraMod.id("textures/entity/hydra.png");

    public HydraRenderer(EntityRendererProvider.Context context) {
        super(context, new HydraModel(context.bakeLayer(HydraModelLayers.HYDRA)), 3.0F);
    }

    @Override
    public HydraRenderState createRenderState() {
        return new HydraRenderState();
    }

    @Override
    public Identifier getTextureLocation(HydraRenderState state) {
        return TEXTURE;
    }

    @Override
    public void extractRenderState(HydraEntity entity, HydraRenderState state, float partialTick) {
        super.extractRenderState(entity, state, partialTick);
        float now = entity.tickCount + partialTick;
        int mask = entity.getBiteMask();
        for (int i = 0; i < HydraEntity.HEADS; i++) {
            state.growth[i] = entity.headGrowth(i);
            state.biteTime[i] = ((mask >> i) & 1) == 1 ? now - entity.clientBiteStart[i] : -1.0F;
        }
        state.animId = entity.clientAnimId;
        state.animTime = entity.clientAnimId == 0 ? -1.0F : now - entity.clientAnimStart;
        state.phase = entity.getPhase();
    }

    /** La hidra no se tumba de lado al morir: su modelo se derrumba con animacion propia. */
    protected float getFlipDegrees() {
        return 0.0F;
    }
}
