#!/usr/bin/env python3
"""Genera texturas PNG (items, bloques, armadura, icono) y todos los JSON de recursos/datos del mod."""
import os, json, random, math
from PIL import Image, ImageDraw

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RES = os.path.join(ROOT, 'src/main/resources')
A = os.path.join(RES, 'assets/hidra')
D = os.path.join(RES, 'data/hidra')

def w(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    open(path, 'w', encoding='utf-8').write(text)

def wj(path, obj):
    w(path, json.dumps(obj, indent=2, ensure_ascii=False) + "\n")

# ------------------------------------------------------------------ pixel art
OUT = (14, 10, 22, 255)
def new(): return Image.new('RGBA', (16, 16), (0, 0, 0, 0))

def sil(mask_fn, base, accents=(), seed=1, light=(110, 108, 124), dark=(18, 16, 26)):
    """Rellena una silueta, genera contorno, luces arriba-izquierda y sombras abajo-derecha."""
    rnd = random.Random(seed)
    img = new(); M = [[mask_fn(x, y) for x in range(16)] for y in range(16)]
    def m(x, y): return 0 <= x < 16 and 0 <= y < 16 and M[y][x]
    for y in range(16):
        for x in range(16):
            if m(x, y):
                c = base[rnd.randrange(len(base))]
                if not m(x, y - 1) or not m(x - 1, y): c = light
                if not m(x, y + 1) or not m(x + 1, y): c = dark
                img.putpixel((x, y), c + (255,))
    for y in range(16):
        for x in range(16):
            if not m(x, y) and any(m(x + dx, y + dy) for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                img.putpixel((x, y), OUT)
    for (x, y, c) in accents:
        if m(x, y): img.putpixel((x, y), c + (255,))
    return img

def rect(x0, y0, ww, hh): return lambda x, y: x0 <= x < x0 + ww and y0 <= y < y0 + hh
def union(*fs): return lambda x, y: any(f(x, y) for f in fs)
def poly(pts):
    im = Image.new('L', (16, 16), 0); ImageDraw.Draw(im).polygon(pts, fill=255)
    return lambda x, y: im.getpixel((x, y)) > 0
def sub(f, g): return lambda x, y: f(x, y) and not g(x, y)

SC = [(34, 34, 42), (44, 44, 54), (28, 28, 36), (54, 52, 66)]
PUR = (150, 70, 235); PUL = (205, 140, 255); PUD = (96, 38, 176)
IV = [(236, 230, 214), (222, 214, 196), (246, 240, 226)]

def line_pixels(img, p0, p1, cols, thick=1):
    n = max(abs(p1[0] - p0[0]), abs(p1[1] - p0[1])) or 1
    for k in range(n + 1):
        x = round(p0[0] + (p1[0] - p0[0]) * k / n); y = round(p0[1] + (p1[1] - p0[1]) * k / n)
        for t in range(thick):
            xx = x - t
            if 0 <= xx < 16 and 0 <= y < 16: img.putpixel((xx, y), cols[min(t, len(cols) - 1)] + (255,))

def outline(img):
    px = img.load(); res = img.copy(); rp = res.load()
    for y in range(16):
        for x in range(16):
            if px[x, y][3] == 0 and any(0 <= x + dx < 16 and 0 <= y + dy < 16 and px[x + dx, y + dy][3] > 0
                                        for dx in (-1, 0, 1) for dy in (-1, 0, 1)):
                rp[x, y] = OUT
    return res

def spr_scale():
    return sil(poly([(8, 1), (13, 4), (13, 10), (8, 14), (3, 10), (3, 4)]), SC,
               [(8, 3, PUR), (8, 4, PUL), (8, 5, PUR), (7, 7, PUD), (9, 8, PUD), (8, 10, PUR), (6, 6, PUD), (10, 6, PUD)], 3)

def spr_fang():
    return sil(poly([(8, 1), (12, 2), (11, 8), (8, 14), (6, 14), (5, 8), (5, 3)]), IV,
               [(8, 3, (255, 255, 250)), (8, 4, (255, 255, 250)), (7, 12, (170, 160, 140))], 4, light=(255, 252, 240), dark=(168, 158, 138))

HEART = ["..oo.....oo..", ".oPPoo.ooPPo.", "oPppPPooPPPPo", "oPpPPPPPPPPPo", "oPPPPPPPPPPqo", ".oPPPPPPPPqo.",
         "..oPPPPPPqo..", "...oPPPPqo...", "....oPPqo....", ".....oqo.....", "......o......"]
def spr_heart():
    img = new(); cols = {'o': OUT[:3], 'P': PUR, 'p': PUL, 'q': PUD}
    for y, row in enumerate(HEART):
        for x, ch in enumerate(row):
            if ch in cols: img.putpixel((x + 2, y + 3), cols[ch] + (255,))
    return img

def spr_core():
    img = new(); px = img.load(); c = 7.5
    for y in range(16):
        for x in range(16):
            d = math.hypot(x - c, y - c)
            if d <= 6.2:
                t = 1 - d / 6.2
                col = (int(60 + 150 * t), int(20 + 90 * t), int(120 + 135 * t))
                if (x + y) % 5 == 0 and d > 2: col = (int(col[0] * .7), int(col[1] * .7), int(col[2] * .8))
                px[x, y] = col + (255,)
            elif d <= 7.3: px[x, y] = OUT
    for (x, y) in ((5, 5), (6, 5), (5, 6)): px[x, y] = (255, 230, 255, 255)
    for (x, y) in ((11, 3), (3, 11), (12, 12)): px[x, y] = (230, 170, 255, 255)
    return img

def spr_essence():
    f = union(rect(7, 1, 2, 3), poly([(6, 4), (10, 4), (13, 8), (13, 12), (11, 14), (5, 14), (3, 12), (3, 8)]))
    img = sil(f, [(110, 50, 200), (130, 64, 220), (96, 40, 180)],
              [(7, 1, (110, 80, 50)), (8, 1, (110, 80, 50)), (7, 2, (140, 100, 60)), (8, 2, (140, 100, 60)), (5, 8, PUL), (5, 9, PUL), (6, 7, PUL)], 5,
              light=(190, 130, 255), dark=(70, 26, 130))
    return img

def spr_spine():
    img = new()
    line_pixels(img, (13, 1), (3, 13), [PUR, PUD, PUL], 3)
    line_pixels(img, (14, 1), (13, 1), [PUL], 1)
    px = img.load()
    for k in range(0, 12, 3):
        x, y = 12 - k, 2 + round(k * 1.2)
        if 0 <= x < 16 and 0 <= y < 16: px[x, y] = PUL + (255,)
    return outline(img)

def spr_sword():
    img = new()
    line_pixels(img, (13, 2), (6, 9), [(168, 168, 184), (108, 108, 126), PUR], 3)
    px = img.load()
    for (x, y) in ((13, 1), (14, 2), (12, 1)): px[x, y] = PUL + (255,)
    for k in range(-2, 3):
        x, y = 5 + k, 10 + k
        px[x, y] = PUD + (255,)
    line_pixels(img, (4, 11), (2, 13), [(98, 66, 44)], 1)
    px[1, 14] = PUR + (255,)
    return outline(img)

def spr_axe():
    img = new(); line_pixels(img, (3, 14), (11, 6), [(98, 66, 44)], 1)
    head = union(rect(8, 1, 6, 3), rect(10, 4, 4, 4), rect(7, 3, 3, 3))
    px = img.load()
    for y in range(16):
        for x in range(16):
            if head(x, y): px[x, y] = ((168, 168, 184) if (x + y) % 2 else (122, 122, 140)) + (255,)
    for (x, y) in ((13, 2), (13, 3), (13, 5), (13, 6)): px[x, y] = PUR + (255,)
    return outline(img)

def spr_pick():
    img = new(); line_pixels(img, (3, 14), (11, 6), [(98, 66, 44)], 1); px = img.load()
    pts = [(3, 4), (4, 3), (5, 2), (6, 2), (7, 2), (8, 2), (9, 2), (10, 3), (11, 3), (12, 4), (13, 5), (14, 6), (13, 7), (12, 6), (11, 5),
           (4, 4), (5, 3), (6, 3), (7, 3), (8, 3), (9, 3), (10, 4), (11, 4), (12, 5), (3, 5), (2, 6)]
    for (x, y) in pts: px[x, y] = ((168, 168, 184) if (x + y) % 2 else (122, 122, 140)) + (255,)
    for (x, y) in ((3, 4), (14, 6), (2, 6)): px[x, y] = PUR + (255,)
    return outline(img)

ARM_ACC = [(7, 4, PUR), (8, 4, PUL), (4, 3, PUD), (11, 3, PUD)]
def spr_helmet():
    return sil(union(rect(3, 3, 10, 6), rect(3, 9, 3, 4), rect(10, 9, 3, 4)), SC,
               [(7, 3, PUR), (8, 3, PUL), (7, 2, PUR), (8, 2, PUR), (6, 8, PUL), (9, 8, PUL), (5, 5, PUD), (10, 5, PUD)], 6)
def spr_chest():
    return sil(sub(union(rect(1, 2, 4, 5), rect(11, 2, 4, 5), rect(3, 2, 10, 12)), rect(6, 2, 4, 2)), SC,
               [(7, 6, PUR), (8, 6, PUL), (7, 7, PUR), (8, 7, PUR), (7, 8, PUD), (8, 8, PUD), (2, 3, PUD), (13, 3, PUD), (5, 11, PUD), (10, 11, PUD)], 7)
def spr_legs():
    return sil(union(rect(3, 2, 10, 4), rect(3, 6, 4, 8), rect(9, 6, 4, 8)), SC,
               [(7, 3, PUR), (8, 3, PUL), (4, 8, PUD), (11, 8, PUD), (4, 12, PUD), (11, 12, PUD)], 8)
def spr_boots():
    return sil(union(rect(2, 5, 5, 7), rect(1, 11, 6, 3), rect(9, 5, 5, 7), rect(9, 11, 6, 3)), SC,
               [(3, 6, PUR), (11, 6, PUR), (2, 12, PUD), (13, 12, PUD)], 9)

def spr_egg():
    img = new(); px = img.load(); rnd = random.Random(11)
    for y in range(16):
        for x in range(16):
            dx, dy = (x - 7.5) / 5.6, (y - 8.0) / 7.2
            if dx * dx + dy * dy <= 1.0:
                c = (46, 18, 84)
                if rnd.random() < 0.28: c = (176, 92, 248)
                elif rnd.random() < 0.25: c = (110, 50, 190)
                px[x, y] = c + (255,)
    for (x, y) in ((5, 4), (6, 3), (5, 5)): px[x, y] = (236, 200, 255, 255)
    return outline(img)

def spr_grass():
    img = new(); px = img.load(); rnd = random.Random(21)
    for bx, hgt in ((2, 8), (4, 11), (6, 7), (7, 13), (9, 9), (11, 12), (13, 7), (14, 10)):
        for k in range(hgt):
            y = 15 - k; x = bx + (1 if k > hgt * .6 and bx % 2 else 0)
            if 0 <= x < 16:
                t = k / hgt
                c = (30 + int(70 * t), 70 + int(60 * t), 90 + int(40 * t)) if t < .75 else (150 + rnd.randrange(40), 70, 220)
                px[x, y] = c + (255,)
    return img

def spr_flower():
    img = new(); px = img.load()
    for y in range(8, 16): px[8, y] = (36, 96, 78, 255); px[7, y + 0] = (28, 74, 62, 255) if y > 10 else (0, 0, 0, 0)
    for (x, y) in ((5, 12), (6, 11), (10, 13), (9, 12)): px[x, y] = (40, 110, 84, 255)
    for (x, y, c) in [(8, 2, PUL), (8, 3, PUR), (6, 3, PUR), (10, 3, PUR), (5, 4, PUD), (11, 4, PUD), (6, 5, PUR), (10, 5, PUR), (7, 4, PUL),
                      (9, 4, PUL), (8, 4, (255, 240, 170)), (7, 6, PUD), (9, 6, PUD), (8, 5, PUR), (8, 6, PUD), (7, 3, PUR), (9, 3, PUR), (4, 3, PUD), (12, 3, PUD)]:
        px[x, y] = c + (255,)
    return img

def armor_layer(path):
    img = Image.new('RGBA', (64, 32), (0, 0, 0, 0)); px = img.load(); rnd = random.Random(33)
    for y in range(32):
        for x in range(64):
            r = random.Random((x // 2) * 131 + (y // 2) * 977)
            c = SC[r.randrange(4)]
            if r.random() < 0.06: c = (PUR, PUD, PUL)[r.randrange(3)]
            px[x, y] = c + (255,)
    os.makedirs(os.path.dirname(path), exist_ok=True); img.save(path)

def save(img, path):
    os.makedirs(os.path.dirname(path), exist_ok=True); img.save(path)

ITEM_SPR = {
 'hydra_scale': spr_scale, 'hydra_fang': spr_fang, 'hydra_heart': spr_heart, 'regenerative_core': spr_core,
 'hydra_essence': spr_essence, 'violet_spine': spr_spine, 'hydra_sword': spr_sword, 'hydra_axe': spr_axe,
 'hydra_pickaxe': spr_pick, 'hydra_helmet': spr_helmet, 'hydra_chestplate': spr_chest, 'hydra_leggings': spr_legs,
 'hydra_boots': spr_boots, 'hydra_spawn_egg': spr_egg,
}
HANDHELD = {'hydra_sword', 'hydra_axe', 'hydra_pickaxe'}
for n, fn in ITEM_SPR.items(): save(fn(), f'{A}/textures/item/{n}.png')
save(spr_grass(), f'{A}/textures/block/hidra_grass.png')
save(spr_flower(), f'{A}/textures/block/hidra_flower.png')
armor_layer(f'{A}/textures/entity/equipment/humanoid/hydra.png')
armor_layer(f'{A}/textures/entity/equipment/humanoid_leggings/hydra.png')
ic = spr_core().resize((128, 128), Image.NEAREST); save(ic, f'{A}/icon.png')

# ------------------------------------------------------------------ modelos / items / bloques
for n in list(ITEM_SPR):
    parent = 'minecraft:item/handheld' if n in HANDHELD else 'minecraft:item/generated'
    wj(f'{A}/models/item/{n}.json', {"parent": parent, "textures": {"layer0": f"hidra:item/{n}"}})
    wj(f'{A}/items/{n}.json', {"model": {"type": "minecraft:model", "model": f"hidra:item/{n}"}})
for b in ('hidra_grass', 'hidra_flower'):
    wj(f'{A}/models/block/{b}.json', {"parent": "minecraft:block/cross", "render_type": "minecraft:cutout", "textures": {"cross": f"hidra:block/{b}"}})
    wj(f'{A}/blockstates/{b}.json', {"variants": {"": {"model": f"hidra:block/{b}"}}})
    wj(f'{A}/models/item/{b}.json', {"parent": "minecraft:item/generated", "textures": {"layer0": f"hidra:block/{b}"}})
    wj(f'{A}/items/{b}.json', {"model": {"type": "minecraft:model", "model": f"hidra:item/{b}"}})
wj(f'{A}/equipment/hydra.json', {"layers": {"humanoid": [{"texture": "hidra:hydra"}], "humanoid_leggings": [{"texture": "hidra:hydra"}]}})

# ------------------------------------------------------------------ idioma (es)
lang = {
 "entity.hidra.hydra_siete_cabezas": "Hidra de las Siete Cabezas",
 "item.hidra.hydra_spawn_egg": "Generador de Hidra de las Siete Cabezas",
 "item.hidra.hydra_scale": "Escama de Hidra", "item.hidra.hydra_fang": "Colmillo de Hidra",
 "item.hidra.hydra_heart": "Corazón de Hidra", "item.hidra.regenerative_core": "Núcleo Regenerativo",
 "item.hidra.hydra_essence": "Esencia de Hidra", "item.hidra.violet_spine": "Espina Violeta",
 "item.hidra.hydra_sword": "Espada de Colmillo de Hidra", "item.hidra.hydra_axe": "Hacha de Colmillo de Hidra",
 "item.hidra.hydra_pickaxe": "Pico de Colmillo de Hidra", "item.hidra.hydra_helmet": "Casco de Escamas de Hidra",
 "item.hidra.hydra_chestplate": "Peto de Escamas de Hidra", "item.hidra.hydra_leggings": "Grebas de Escamas de Hidra",
 "item.hidra.hydra_boots": "Botas de Escamas de Hidra",
 "block.hidra.hidra_grass": "Hierba de la Hidra", "block.hidra.hidra_flower": "Flor Violeta de la Hidra",
 "msg.hidra.phase2": "¡La Hidra se enfurece! Sus cabezas se regeneran más rápido.",
 "msg.hidra.phase3": "¡Última resistencia! La Hidra ataca con todas sus cabezas.",
 "msg.hidra.cauterized": "¡Las heridas de la Hidra se cauterizan! Ya no puede regenerar cabezas.",
 "msg.hidra.cauter_head": "¡Has cauterizado un muñón! Esa cabeza tardará mucho en regenerarse.",
 "msg.hidra.set_bonus": "Bonificación del conjunto de Hidra: regeneración pasiva.",
}
wj(f'{A}/lang/en_us.json', lang)
wj(f'{A}/lang/es_es.json', lang)
wj(f'{A}/lang/es_mx.json', lang)

# ------------------------------------------------------------------ datos
def item(name, lo=None, hi=None, cond=None):
    e = {"type": "minecraft:item", "name": name}
    if lo is not None:
        e["functions"] = [{"function": "minecraft:set_count", "count": {"type": "minecraft:uniform", "min": lo, "max": hi}}]
    pool = {"rolls": 1, "entries": [e]}
    if cond is not None: pool["conditions"] = [{"condition": "minecraft:random_chance", "chance": cond}]
    return pool
wj(f'{D}/loot_table/entities/hydra_siete_cabezas.json', {"type": "minecraft:entity", "pools": [
    item("hidra:hydra_heart"), item("hidra:regenerative_core"),
    item("hidra:hydra_scale", 30, 42), item("hidra:hydra_fang", 6, 10), item("hidra:hydra_essence", 3, 6),
    item("hidra:violet_spine", 4, 8), item("minecraft:diamond", 6, 12), item("minecraft:emerald", 8, 16),
    item("minecraft:netherite_scrap", 1, 3, 0.6), item("minecraft:enchanted_golden_apple", 1, 1, 0.4),
    item("minecraft:amethyst_shard", 16, 32)]})

for b in ('hidra_grass', 'hidra_flower'):
    wj(f'{D}/loot_table/blocks/{b}.json', {"type": "minecraft:block", "pools": [{"rolls": 1, "entries": [{
        "type": "minecraft:item", "name": f"hidra:{b}", "conditions": [{"condition": "minecraft:match_tool", "predicate": {
            "predicates": {"minecraft:enchantments": [{"enchantments": "minecraft:silk_touch", "levels": {"min": 1}}]}}}]}]}],
        "random_sequence": f"hidra:blocks/{b}"})

def shaped(name, pattern, key, result, cat="equipment"):
    wj(f'{D}/recipe/{name}.json', {"type": "minecraft:crafting_shaped", "category": cat, "key": key,
                                  "pattern": pattern, "result": {"id": f"hidra:{name}", "count": 1}})
F = "hidra:hydra_fang"; S = "hidra:hydra_scale"; H = "hidra:hydra_heart"; E = "hidra:hydra_essence"; V = "hidra:violet_spine"
shaped('hydra_sword', ["F", "F", "T"], {"F": F, "T": "minecraft:stick"}, 1)
shaped('hydra_axe', ["FF", "FT", " T"], {"F": F, "T": "minecraft:stick"}, 1)
shaped('hydra_pickaxe', ["FFF", " T ", " T "], {"F": F, "T": "minecraft:stick"}, 1)
shaped('hydra_helmet', ["SSS", "S S"], {"S": S}, 1)
shaped('hydra_chestplate', ["S S", "SHS", "SSS"], {"S": S, "H": H}, 1)
shaped('hydra_leggings', ["SSS", "S S", "S S"], {"S": S}, 1)
shaped('hydra_boots', ["S S", "S S"], {"S": S}, 1)

wj(f'{D}/tags/item/repairs_hydra_gear.json', {"values": ["hidra:hydra_scale"]})
def tag(name, vals): wj(f'{RES}/data/minecraft/tags/item/{name}.json', {"values": vals})
tag('swords', ["hidra:hydra_sword"]); tag('axes', ["hidra:hydra_axe"]); tag('pickaxes', ["hidra:hydra_pickaxe"])
tag('head_armor', ["hidra:hydra_helmet"]); tag('chest_armor', ["hidra:hydra_chestplate"])
tag('leg_armor', ["hidra:hydra_leggings"]); tag('foot_armor', ["hidra:hydra_boots"])

wj(f'{D}/worldgen/configured_feature/hydra_lair.json', {"type": "hidra:hydra_lair", "config": {}})
wj(f'{D}/worldgen/placed_feature/hydra_lair.json', {"feature": "hidra:hydra_lair", "placement": [
    {"type": "minecraft:rarity_filter", "chance": 120}, {"type": "minecraft:in_square"},
    {"type": "minecraft:heightmap", "heightmap": "OCEAN_FLOOR_WG"}, {"type": "minecraft:biome"}]})
print("recursos OK")
