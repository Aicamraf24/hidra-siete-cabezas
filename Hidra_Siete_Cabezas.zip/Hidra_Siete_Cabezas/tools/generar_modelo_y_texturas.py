#!/usr/bin/env python3
"""
Genera (a partir de UNA sola definicion de cajas) :
  - src/client/java/com/hidra/client/model/HydraLayer.java   (geometria voxel de la hidra)
  - src/main/resources/assets/hidra/textures/entity/hydra.png (textura del modelo)
La geometria y la textura salen de la misma lista, asi que los UV siempre coinciden.
Uso: python3 tools/generar_modelo_y_texturas.py   (necesita Pillow)
"""
import random, os
from PIL import Image

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
TEX = 512

# nombre: (ancho, alto, fondo, tipo de pintura)
BOX = {
 'body': (64, 48, 96, 'scale'), 'chest': (72, 38, 34, 'scale'), 'haunch': (68, 38, 30, 'scale'),
 'hump': (44, 10, 36, 'scale'),
 'spikeA': (8, 16, 8, 'spike'), 'spikeB': (6, 10, 6, 'spike'),
 'thigh': (20, 28, 20, 'scale'), 'foot': (18, 20, 24, 'scale'), 'claw': (5, 6, 7, 'tooth'),
 't1': (28, 24, 26, 'scale'), 't2': (22, 20, 26, 'scale'), 't3': (16, 16, 26, 'scale'),
 't4': (12, 12, 26, 'scale'), 't5': (8, 9, 24, 'scale'), 'tspike': (5, 9, 5, 'spike'),
 'neck': (12, 22, 12, 'neck'), 'skull': (20, 13, 30, 'skull'), 'jaw': (17, 5, 26, 'jaw'),
 'tooth': (3, 6, 3, 'tooth'), 'eye': (2, 4, 5, 'eye'), 'horn': (4, 5, 10, 'spike'),
 'stump': (12, 7, 12, 'stump'),
}

# ---- empaquetado de UV (estantes) ----
def pack():
    items = sorted(BOX.items(), key=lambda kv: -(kv[1][2] + kv[1][1]))
    uv, x, y, shelf = {}, 0, 0, 0
    for name, (w, h, d, _) in items:
        rw, rh = 2 * (w + d), d + h
        if x + rw > TEX:
            x, y, shelf = 0, y + shelf, 0
        uv[name] = (x, y)
        x += rw
        shelf = max(shelf, rh)
    assert y + shelf <= TEX, "textura demasiado pequena"
    return uv
UV = pack()

def f(v): return "%.1fF" % v

def cube(name, x, y, z):
    w, h, d, _ = BOX[name]
    u, v = UV[name]
    return ".texOffs(%d, %d).addBox(%s, %s, %s, %s, %s, %s)" % (u, v, f(x), f(y), f(z), f(w), f(h), f(d))

def build_java():
    L = []
    A = L.append
    A("package com.hidra.client.model;\n")
    A("import net.minecraft.client.model.geom.PartPose;")
    A("import net.minecraft.client.model.geom.builders.CubeListBuilder;")
    A("import net.minecraft.client.model.geom.builders.LayerDefinition;")
    A("import net.minecraft.client.model.geom.builders.MeshDefinition;")
    A("import net.minecraft.client.model.geom.builders.PartDefinition;\n")
    A("/** GENERADO por tools/generar_modelo_y_texturas.py - no editar a mano. Geometria 100 % cubica (voxel). */")
    A("public final class HydraLayer {")
    A("    public static final int HEADS = 7;")
    A("    private HydraLayer() {}\n")
    A("    public static LayerDefinition create() {")
    A("        MeshDefinition mesh = new MeshDefinition();")
    A("        PartDefinition root = mesh.getRoot();\n")
    # cuerpo
    body = "CubeListBuilder.create()" + cube('body', -32, -24, -48) + cube('chest', -36, -19, -56) \
        + cube('haunch', -34, -18, 26) + cube('hump', -22, -34, -34)
    zs = [-40, -29, -18, -7, 4, 15, 26, 37]
    for k, z in enumerate(zs):
        nm = 'spikeA' if k % 2 == 0 else 'spikeB'
        w, h, d, _ = BOX[nm]
        top = -34 if z < -14 and z > -44 else -24
        body += cube(nm, -w / 2, top - h, z)
    A("        root.addOrReplaceChild(\"body\", %s, PartPose.offset(0.0F, -36.0F, 0.0F));\n" % body)
    # patas
    for nm, x, z in (("FL", -32, -30), ("FR", 32, -30), ("BL", -32, 30), ("BR", 32, 30)):
        thigh = "CubeListBuilder.create()" + cube('thigh', -10, 0, -10)
        A("        PartDefinition leg%s = root.addOrReplaceChild(\"leg%s\", %s, PartPose.offset(%s, -24.0F, %s));" % (nm, nm, thigh, f(x), f(z)))
        foot = "CubeListBuilder.create()" + cube('foot', -9, 0, -12) + cube('claw', -8, 14, -19) \
            + cube('claw', -2, 14, -19) + cube('claw', 4, 14, -19)
        A("        leg%s.addOrReplaceChild(\"foot%s\", %s, PartPose.offset(0.0F, 28.0F, 0.0F));\n" % (nm, nm, foot))
    # cola
    segs = [('t1', 24), ('t2', 20), ('t3', 16), ('t4', 12), ('t5', 9)]
    parent = "root"
    for k, (t, h) in enumerate(segs):
        w = BOX[t][0]
        b = "CubeListBuilder.create()" + cube(t, -w / 2, -h / 2, 0)
        if k < 4:
            b += cube('tspike', -2, -h / 2 - 9, 10)
        pose = "PartPose.offset(0.0F, -40.0F, 44.0F)" if k == 0 else "PartPose.offset(0.0F, 0.0F, 26.0F)"
        var = "tail%d" % (k + 1)
        A("        PartDefinition %s = %s.addOrReplaceChild(\"%s\", %s, %s);" % (var, parent, var, b, pose))
        parent = var
    A("")
    # cuellos / cabezas / munones
    for i in range(7):
        c = i - 3
        bx = c * 9
        bz = -30 - (3 - abs(c)) * 3
        neck = "CubeListBuilder.create()" + cube('neck', -6, -22, -6)
        A("        PartDefinition n%da = root.addOrReplaceChild(\"n%da\", %s, PartPose.offsetAndRotation(%s, -58.0F, %s, 0.20F, 0.0F, %s));"
          % (i, i, neck, f(bx), f(bz), f(c * 0.20)))
        A("        PartDefinition n%db = n%da.addOrReplaceChild(\"n%db\", %s, PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.35F, 0.0F, %s));"
          % (i, i, i, neck, f(c * 0.05)))
        A("        PartDefinition n%dc = n%db.addOrReplaceChild(\"n%dc\", %s, PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, 0.35F, 0.0F, %s));"
          % (i, i, i, neck, f(c * 0.03)))
        head = "CubeListBuilder.create()" + cube('skull', -10, -11, -26)
        for tx in (-9.5, 6.5):
            for tz in (-25.5, -17.5, -9.5):
                head += cube('tooth', tx, 2, tz)
        head += cube('eye', -11, -8, -22) + cube('eye', 9, -8, -22) + cube('horn', -9, -16, -4) + cube('horn', 5, -16, -4)
        A("        PartDefinition h%d = n%dc.addOrReplaceChild(\"h%d\", %s, PartPose.offsetAndRotation(0.0F, -22.0F, 0.0F, -0.78F, 0.0F, 0.0F));" % (i, i, i, head))
        jaw = "CubeListBuilder.create()" + cube('jaw', -8.5, 0, -24)
        for tx in (-8, 5):
            for tz in (-23, -15, -7):
                jaw += cube('tooth', tx, -5, tz)
        A("        h%d.addOrReplaceChild(\"j%d\", %s, PartPose.offset(0.0F, 2.0F, 0.0F));" % (i, i, jaw))
        stump = "CubeListBuilder.create()" + cube('stump', -6, -4, -6)
        A("        root.addOrReplaceChild(\"s%d\", %s, PartPose.offset(%s, -58.0F, %s));\n" % (i, stump, f(bx), f(bz)))
    A("        return LayerDefinition.create(mesh, %d, %d);" % (TEX, TEX))
    A("    }\n}")
    return "\n".join(L) + "\n"

# ---------------- pintura ----------------
random.seed(7)
PAL = {
 'scale': [(26, 26, 32), (34, 34, 42), (20, 20, 26), (44, 44, 54), (16, 14, 22), (58, 56, 70)],
 'neckl': [(112, 108, 114), (134, 130, 136), (94, 90, 98), (152, 148, 152)],
 'neckd': [(30, 30, 38), (38, 38, 48), (24, 24, 30), (48, 46, 60)],
 'spike': [(112, 48, 200), (140, 70, 230), (90, 34, 170), (172, 104, 255)],
 'glow': [(190, 70, 255), (222, 124, 255), (150, 40, 220), (240, 170, 255)],
 'tooth': [(236, 230, 214), (214, 206, 188), (250, 246, 232), (196, 188, 170)],
 'stump': [(96, 22, 70), (130, 36, 96), (70, 14, 58), (160, 60, 150)],
}

def cellfill(img, x, y, w, h, pal, cell, accent=None, accp=0.0):
    for yy in range(y, y + h):
        for xx in range(x, x + w):
            cx, cy = (xx - x) // cell, (yy - y) // cell
            rnd = random.Random(hash((xx // cell * 7919, yy // cell * 104729, cx * 31 + cy, x, y)))
            col = pal[rnd.randrange(len(pal))]
            if accent and rnd.random() < accp:
                col = accent[rnd.randrange(len(accent))]
            img.putpixel((xx, yy), col + (255,))

def faces(u, v, w, h, d):
    return {'top': (u + d, v, w, d), 'bottom': (u + d + w, v, w, d), 'right': (u, v + d, d, h),
            'front': (u + d, v + d, w, h), 'left': (u + d + w, v + d, d, h), 'back': (u + 2 * d + w, v + d, w, h)}

def paint(img):
    for name, (w, h, d, kind) in BOX.items():
        u, v = UV[name]
        F = faces(u, v, w, h, d)
        for fn, (x, y, fw, fh) in F.items():
            if fw <= 0 or fh <= 0:
                continue
            if kind == 'scale':
                cellfill(img, x, y, fw, fh, PAL['scale'], 4, PAL['spike'], 0.035)
            elif kind == 'spike':
                cellfill(img, x, y, fw, fh, PAL['spike'], 2)
            elif kind == 'tooth':
                cellfill(img, x, y, fw, fh, PAL['tooth'], 2)
            elif kind == 'eye':
                cellfill(img, x, y, fw, fh, PAL['glow'], 1)
            elif kind == 'stump':
                cellfill(img, x, y, fw, fh, PAL['stump'], 2, PAL['glow'], 0.15)
            elif kind == 'neck':
                light = fn in ('front', 'bottom')
                cellfill(img, x, y, fw, fh, PAL['neckl'] if light else PAL['neckd'], 4, PAL['spike'], 0.04)
            elif kind == 'skull':
                if fn == 'bottom':
                    cellfill(img, x, y, fw, fh, PAL['glow'], 2)
                elif fn == 'front':
                    cellfill(img, x, y, fw, fh, PAL['scale'], 2, PAL['glow'], 0.12)
                else:
                    cellfill(img, x, y, fw, fh, PAL['scale'], 2, PAL['spike'], 0.05)
            elif kind == 'jaw':
                if fn == 'top':
                    cellfill(img, x, y, fw, fh, PAL['glow'], 2)
                else:
                    cellfill(img, x, y, fw, fh, PAL['scale'], 2, PAL['neckl'], 0.25)
    return img

if __name__ == '__main__':
    java = build_java()
    jp = os.path.join(ROOT, 'src/client/java/com/hidra/client/model/HydraLayer.java')
    os.makedirs(os.path.dirname(jp), exist_ok=True)
    open(jp, 'w').write(java)
    img = Image.new('RGBA', (TEX, TEX), (0, 0, 0, 0))
    paint(img)
    tp = os.path.join(ROOT, 'src/main/resources/assets/hidra/textures/entity/hydra.png')
    os.makedirs(os.path.dirname(tp), exist_ok=True)
    img.save(tp)
    print("OK", jp, tp, "cajas:", len(BOX))
